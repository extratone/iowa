window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84090",
                  "name" : "#TheWheelOfTime",
                  "description" : "Watch Now on Prime Video"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2021-11-20 11:12:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-11-20 11:12:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84090",
                  "name" : "#TheWheelOfTime",
                  "description" : "Watch Now on Prime Video"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2021-11-20 12:00:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-11-20 12:00:58",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84090",
                  "name" : "#TheWheelOfTime",
                  "description" : "Watch Now on Prime Video"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2021-11-20 12:02:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-11-20 12:02:08",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  }
]