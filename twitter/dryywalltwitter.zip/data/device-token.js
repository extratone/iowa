window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "ezLiTkT5c4uSLcjQsoRgTMCvfs9Tu4RqmmxyWbq8",
      "createdAt" : "2021-07-05T01:26:46.877Z",
      "lastSeenAt" : "2021-08-01T05:02:57.948Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "tc2j462hILSiXpMfzTsCR8eIEgsRj9ZyrwHQhQpl",
      "createdAt" : "2021-11-19T06:06:49.101Z",
      "lastSeenAt" : "2021-11-19T06:06:49.103Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "f7vQFI72FGcxNO2KGMxzlh2akFGqfVBIBDnf99tv",
      "createdAt" : "2021-12-13T05:51:43.753Z",
      "lastSeenAt" : "2021-12-13T05:51:43.754Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "Es6udCKUdEWZLcWUJzxL0MdnAQCqUmNRwCKaKviK",
      "createdAt" : "2021-12-08T10:54:22.643Z",
      "lastSeenAt" : "2021-12-14T21:54:07.113Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Zxrn9H4M7oQZNmfIs58dBEmZ3sEOZhloNs1a8KcZ",
      "createdAt" : "2021-11-23T01:59:30.066Z",
      "lastSeenAt" : "2021-12-15T00:55:36.263Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]