window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1470265539167600641",
      "fullText" : "Now playing: Rock Those Jingle Bells by DeDe #nowplaying Listen live: https://t.co/DswV8KHFmv https://t.co/k5aqB5nxr1",
      "expandedUrl" : "https://twitter.com/i/web/status/1470265539167600641"
    }
  },
  {
    "like" : {
      "tweetId" : "1470222704041029635",
      "fullText" : "We did everything we were told. We had vaccinations when they were available at go in July. 2nd dose beginning of October. Now we have to wait until March for booster. Hopefully Omnicron won’t be everywhere by then. Thanks Morrison and Hunt.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470222704041029635"
    }
  },
  {
    "like" : {
      "tweetId" : "1470261971811549187",
      "fullText" : "SAN CAMILO VARGAS INMENSO.\nhttps://t.co/0QHZtH3heT",
      "expandedUrl" : "https://twitter.com/i/web/status/1470261971811549187"
    }
  },
  {
    "like" : {
      "tweetId" : "1470263207382040576",
      "fullText" : "Now playing: Hello Mary Lou by Ricky Nelson #nowplaying Listen live: https://t.co/DswV8KHFmv https://t.co/RgyYXvZbis",
      "expandedUrl" : "https://twitter.com/i/web/status/1470263207382040576"
    }
  },
  {
    "like" : {
      "tweetId" : "1469703534211833857",
      "fullText" : "Back to the old days. No bots. Just early mornings and hands https://t.co/nMWTVdh35G",
      "expandedUrl" : "https://twitter.com/i/web/status/1469703534211833857"
    }
  },
  {
    "like" : {
      "tweetId" : "1469694778946342917",
      "fullText" : "I pray for everyone in dark places, including myself. Be strong. You are loved.",
      "expandedUrl" : "https://twitter.com/i/web/status/1469694778946342917"
    }
  },
  {
    "like" : {
      "tweetId" : "1470262850165874691",
      "fullText" : "06:22: \"Easy on Me\" von Adele",
      "expandedUrl" : "https://twitter.com/i/web/status/1470262850165874691"
    }
  },
  {
    "like" : {
      "tweetId" : "1470266610023907328",
      "fullText" : "Yo. Any of my pals here into anime? My oldest loves it and I have no effing clue. Need some good gift ideas.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470266610023907328"
    }
  },
  {
    "like" : {
      "tweetId" : "1470262320077152259",
      "fullText" : "https://t.co/x7mT0hFM6R",
      "expandedUrl" : "https://twitter.com/i/web/status/1470262320077152259"
    }
  },
  {
    "like" : {
      "tweetId" : "1470266459670601732",
      "fullText" : "me reading the TL right now. https://t.co/PcvMO6bkJw",
      "expandedUrl" : "https://twitter.com/i/web/status/1470266459670601732"
    }
  },
  {
    "like" : {
      "tweetId" : "1470265449619283971",
      "fullText" : "06:32: \"All I Know So Far\" von Pink",
      "expandedUrl" : "https://twitter.com/i/web/status/1470265449619283971"
    }
  },
  {
    "like" : {
      "tweetId" : "1470075005467770887",
      "fullText" : "we moving on &amp; up next year.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470075005467770887"
    }
  },
  {
    "like" : {
      "tweetId" : "1470265199215235074",
      "fullText" : "remember when weird nyr twitter would portray derick as the biggest clown of all and people would actually get upset that we weren’t writing better scripts for him",
      "expandedUrl" : "https://twitter.com/i/web/status/1470265199215235074"
    }
  },
  {
    "like" : {
      "tweetId" : "1470262577309487106",
      "fullText" : "Now playing: Rockin' Robin by Bobby Day #nowplaying Listen live: https://t.co/DswV8KHFmv https://t.co/i1Ldscr8EL",
      "expandedUrl" : "https://twitter.com/i/web/status/1470262577309487106"
    }
  },
  {
    "like" : {
      "tweetId" : "1470263836632518658",
      "fullText" : "Now playing: Way To Know feat. Downtown Mystic by Bruce Engler #nowplaying Listen live: https://t.co/DswV8KHFmv https://t.co/6D3LqcUlie",
      "expandedUrl" : "https://twitter.com/i/web/status/1470263836632518658"
    }
  },
  {
    "like" : {
      "tweetId" : "1470266235023609856",
      "fullText" : "Now playing: Follow You by Imagine Dragons #nowplaying Listen live: https://t.co/DswV8KHFmv https://t.co/4IOMCixQ54",
      "expandedUrl" : "https://twitter.com/i/web/status/1470266235023609856"
    }
  },
  {
    "like" : {
      "tweetId" : "1470265912028803073",
      "fullText" : "https://t.co/6dL7j6e0Bz",
      "expandedUrl" : "https://twitter.com/i/web/status/1470265912028803073"
    }
  },
  {
    "like" : {
      "tweetId" : "1470263608844169218",
      "fullText" : "Al ver imágenes de varias definiciones deportivas, noto que nadie lleva tapabocas, como si el coronavirus ya no estuviera entre nosotros. ¿Será que estoy muy paranoico y le tengo miedo a un virus que casi me manda a la lona en julio o que el resto anda en una actitud suicida?",
      "expandedUrl" : "https://twitter.com/i/web/status/1470263608844169218"
    }
  },
  {
    "like" : {
      "tweetId" : "1470255771778646018",
      "fullText" : "With #AlboForPM taking delivery of a #SitDownBoofHead mug, I made a digital version as a reminder of that memrable moment. Credit for mug @nordacious 13 Dec 2021 https://t.co/D50XjMPyAA",
      "expandedUrl" : "https://twitter.com/i/web/status/1470255771778646018"
    }
  },
  {
    "like" : {
      "tweetId" : "1470255619823202304",
      "fullText" : "Teresa Randal - Just in case you've forgotten Scott's slick little damage control video from January 4, 2020. Have another look. So many announcements 13 Dec 2021 https://t.co/dsfdjx8x9b",
      "expandedUrl" : "https://twitter.com/i/web/status/1470255619823202304"
    }
  },
  {
    "like" : {
      "tweetId" : "1470265793699012610",
      "fullText" : "Julio de este 2021 fue para mí un antes y un después de enfrentarme a una enfermedad como la Covid-19. Para mí desde esos días quedó muy claro que cualquier medida que ayude a detener ese virus es bienvenida. El coronavirus no conoce de nuestras angustias existenciales o legales.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470265793699012610"
    }
  },
  {
    "like" : {
      "tweetId" : "1470265101664108552",
      "fullText" : "https://t.co/GnYCT4ZXpA",
      "expandedUrl" : "https://twitter.com/i/web/status/1470265101664108552"
    }
  },
  {
    "like" : {
      "tweetId" : "1470264718463889412",
      "fullText" : "Now playing: Chasing The Sun by The Wanted #nowplaying Listen live: https://t.co/DswV8KHFmv https://t.co/y8BlEirTt3",
      "expandedUrl" : "https://twitter.com/i/web/status/1470264718463889412"
    }
  },
  {
    "like" : {
      "tweetId" : "1470264287763566593",
      "fullText" : "https://t.co/rqAIMPz7NV",
      "expandedUrl" : "https://twitter.com/i/web/status/1470264287763566593"
    }
  },
  {
    "like" : {
      "tweetId" : "1470124190749573120",
      "fullText" : "So those not jabbed are told it works and to go get it. But those of us that are jabbed are being told it doesn’t work and now we need booster. 🤷🏻‍♂️  #NationalSwitchOff",
      "expandedUrl" : "https://twitter.com/i/web/status/1470124190749573120"
    }
  },
  {
    "like" : {
      "tweetId" : "1469781903272136704",
      "fullText" : "Have to luv ⭐️Zali Steggall ⭐️ she has Scotty shitting his pants again and all she has to say is the word “integrity” 🤣🤣🤣🤣🤣🤣",
      "expandedUrl" : "https://twitter.com/i/web/status/1469781903272136704"
    }
  },
  {
    "like" : {
      "tweetId" : "1470266967697149952",
      "fullText" : "@_sara_jade_ He's a national embarrassment.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470266967697149952"
    }
  },
  {
    "like" : {
      "tweetId" : "1470257290137661444",
      "fullText" : "What COVID has uncovered is the number of people with a woeful grasp of mathematics and probability even in the broadest sense. \n\nAnd not just anti-vaxers. Also journalists and politicians.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470257290137661444"
    }
  },
  {
    "like" : {
      "tweetId" : "1470255369440030720",
      "fullText" : "NT Acting Chief Minister says more cases are expected to emerge in the coming days https://t.co/tqEiCvlzEr",
      "expandedUrl" : "https://twitter.com/i/web/status/1470255369440030720"
    }
  },
  {
    "like" : {
      "tweetId" : "1470267941958701057",
      "fullText" : "06:42: \"The Show Must Go On\" von Queen",
      "expandedUrl" : "https://twitter.com/i/web/status/1470267941958701057"
    }
  },
  {
    "like" : {
      "tweetId" : "1469878658235916288",
      "fullText" : "My pride too big, I’ll think about you everyday &amp; you’ll never hear from me!",
      "expandedUrl" : "https://twitter.com/i/web/status/1469878658235916288"
    }
  },
  {
    "like" : {
      "tweetId" : "1470241223424184320",
      "fullText" : "It's been almost 6 months since my 2nd #CovidVaccine shot, so I was hoping to get a booster before thousands of holidaymakers descend on this little coastal town. But the local pharmacists tell me that they don't even know when they'll be able to start giving boosters.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470241223424184320"
    }
  },
  {
    "like" : {
      "tweetId" : "1470183389210689536",
      "fullText" : "@Vittidinia @bruce_haigh I think we are very safe in current situation to place that bet. ANY Labor government will be infinitely better than the most corrupt and incompetent Federal government in Australia's history.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470183389210689536"
    }
  },
  {
    "like" : {
      "tweetId" : "1470004739370729474",
      "fullText" : "@JonesHowdareyou The joy after Campbell Newman was voted out in spectacular fashion was truly memorable. I’m hoping for that. I desperately want our seat to change hands and I hope so many others do too.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470004739370729474"
    }
  },
  {
    "like" : {
      "tweetId" : "1470247448551378944",
      "fullText" : "The identical attacks by Josh Frydenberg and Tim Wilson on the independents are obviously coordinated.  \nThis is why you should vote for #Mon4Kooyong and #zoeforgoldstein.  \nThey pass the scream test!  \n\n#voicesofkooyong #KooyongVotes #GoldsteinVotes #auspol",
      "expandedUrl" : "https://twitter.com/i/web/status/1470247448551378944"
    }
  },
  {
    "like" : {
      "tweetId" : "1470267743387721728",
      "fullText" : "Now playing: The Lighthouse by Amity Dry #nowplaying Listen live: https://t.co/DswV8KZgL5 https://t.co/tHYDgSXN6l",
      "expandedUrl" : "https://twitter.com/i/web/status/1470267743387721728"
    }
  },
  {
    "like" : {
      "tweetId" : "1470268713207226369",
      "fullText" : "Richard or Judy? Choose.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470268713207226369"
    }
  },
  {
    "like" : {
      "tweetId" : "1470267281804562437",
      "fullText" : "https://t.co/rRrrk9qnzZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1470267281804562437"
    }
  },
  {
    "like" : {
      "tweetId" : "1470266734460428291",
      "fullText" : "06:37: \"Iko Iko\" von Justin Wellington feat. Small Jam",
      "expandedUrl" : "https://twitter.com/i/web/status/1470266734460428291"
    }
  },
  {
    "like" : {
      "tweetId" : "1470185148482088961",
      "fullText" : "Jim Chalmers says the two highest-taxing governments of the past 30 years have been Coalition governments, especially the current one. Is that correct? ✔️\n#FactCheck \nhttps://t.co/nJUyVMZCyE https://t.co/SnEaRRMhFs",
      "expandedUrl" : "https://twitter.com/i/web/status/1470185148482088961"
    }
  },
  {
    "like" : {
      "tweetId" : "1470255438331400193",
      "fullText" : "Never gets old!!! https://t.co/WEm3wxUsuv",
      "expandedUrl" : "https://twitter.com/i/web/status/1470255438331400193"
    }
  },
  {
    "like" : {
      "tweetId" : "1470258170484326404",
      "fullText" : "Following major structural defects being found in NSW trains built in South Korea, we sign a billion dollar contract for more South Korea hardware. What could go wrong? 🤷🏻‍♂️ https://t.co/w6SgmydsHw",
      "expandedUrl" : "https://twitter.com/i/web/status/1470258170484326404"
    }
  },
  {
    "like" : {
      "tweetId" : "1470266757046624256",
      "fullText" : "@bradpsychology Not to mention sanctioned by Peter Costello former LNP treasurer and Chairman of Channel 9 Media which owns the Age.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470266757046624256"
    }
  },
  {
    "like" : {
      "tweetId" : "1470065588110348294",
      "fullText" : "I be finding out everything just by being quiet 😂",
      "expandedUrl" : "https://twitter.com/i/web/status/1470065588110348294"
    }
  },
  {
    "like" : {
      "tweetId" : "1470247120905121793",
      "fullText" : "https://t.co/tR8i8BK1wV",
      "expandedUrl" : "https://twitter.com/i/web/status/1470247120905121793"
    }
  },
  {
    "like" : {
      "tweetId" : "1469910029767569408",
      "fullText" : "When you try proposing to your girl but she starts running away https://t.co/ngWhTsrVIS",
      "expandedUrl" : "https://twitter.com/i/web/status/1469910029767569408"
    }
  },
  {
    "like" : {
      "tweetId" : "1470260838304870400",
      "fullText" : "@nobby15 @ChrisMac1270 What about medivac - was that not ungodly too! Yet Jacqui agreed to cancel it!!  &amp; still won’t tell us why!",
      "expandedUrl" : "https://twitter.com/i/web/status/1470260838304870400"
    }
  },
  {
    "like" : {
      "tweetId" : "1470267331460935683",
      "fullText" : "Amigos: La vida está afuera, pero el coronavirus también. Que el espíritu fiestero de diciembre no los haga caer en una UCI por falta de cuidado. Sé que ya son casi dos años de esta pandemia y que estamos cansados, pero hay que ser precavidos con este enemigo invisible y mutante.",
      "expandedUrl" : "https://twitter.com/i/web/status/1470267331460935683"
    }
  },
  {
    "like" : {
      "tweetId" : "1470257873389195265",
      "fullText" : "#Scomo  “So Australia can be a stronger partner for so many others.”  BL short of breath SWALLOWS HARD, FEAR . INVERTED MOUTH STRESS COMPRESSED LIPS holds back what he’d really like to say. Holds in aggression, anger tightly CLENCHED FISTS  . Stuttering insincerity. #Moon Jae-In https://t.co/6ti1xRwnTD",
      "expandedUrl" : "https://twitter.com/i/web/status/1470257873389195265"
    }
  },
  {
    "like" : {
      "tweetId" : "1470266924395159555",
      "fullText" : "Now playing: Reasons by Brittany Maggs #nowplaying Listen live: https://t.co/DswV8KHFmv https://t.co/6WKJ8oLTev",
      "expandedUrl" : "https://twitter.com/i/web/status/1470266924395159555"
    }
  },
  {
    "like" : {
      "tweetId" : "432018267138297856",
      "fullText" : "@vixenofthevales oooh boy",
      "expandedUrl" : "https://twitter.com/i/web/status/432018267138297856"
    }
  },
  {
    "like" : {
      "tweetId" : "431906046857060352",
      "fullText" : "@starkyy_ i kinda envy girls. vaginas seems pretty fun",
      "expandedUrl" : "https://twitter.com/i/web/status/431906046857060352"
    }
  },
  {
    "like" : {
      "tweetId" : "432016896825651200",
      "fullText" : "@vixenofthevales why does your friend know so many teens",
      "expandedUrl" : "https://twitter.com/i/web/status/432016896825651200"
    }
  },
  {
    "like" : {
      "tweetId" : "431858907716128769",
      "fullText" : "ONE LAYER TO FIND THEM ALL AND IN THE SWAMPNESS BIND THEM",
      "expandedUrl" : "https://twitter.com/i/web/status/431858907716128769"
    }
  },
  {
    "like" : {
      "tweetId" : "431896891626766336",
      "fullText" : "i hope x gives it to zimmerman. and by it i mean death",
      "expandedUrl" : "https://twitter.com/i/web/status/431896891626766336"
    }
  },
  {
    "like" : {
      "tweetId" : "432018049961447424",
      "fullText" : "can 5.45 actually get you a whopper and a forty",
      "expandedUrl" : "https://twitter.com/i/web/status/432018049961447424"
    }
  },
  {
    "like" : {
      "tweetId" : "431895717624709120",
      "fullText" : "Negasonic Teenage Warhead RT @Brohan_Cruyff: MSNBC: The Saiyan Saga (via @morninggloria) | http://t.co/t0rhwibaPB",
      "expandedUrl" : "https://twitter.com/i/web/status/431895717624709120"
    }
  },
  {
    "like" : {
      "tweetId" : "432012395779608576",
      "fullText" : "sochi is a wonderland",
      "expandedUrl" : "https://twitter.com/i/web/status/432012395779608576"
    }
  },
  {
    "like" : {
      "tweetId" : "431913935151697920",
      "fullText" : "@buerstemple im kiddin go ahead",
      "expandedUrl" : "https://twitter.com/i/web/status/431913935151697920"
    }
  },
  {
    "like" : {
      "tweetId" : "431912695541952512",
      "fullText" : "@starkyy_ After a while all the cocksleeves and cups sorta feel the same. with dildos you can have size and length and texture...",
      "expandedUrl" : "https://twitter.com/i/web/status/431912695541952512"
    }
  },
  {
    "like" : {
      "tweetId" : "432011426274611200",
      "fullText" : "@brostitute i've regretted not buying enough whoppers, and i've regretted giving whoppers away. there is a balance",
      "expandedUrl" : "https://twitter.com/i/web/status/432011426274611200"
    }
  },
  {
    "like" : {
      "tweetId" : "431849778318557184",
      "fullText" : "Me as Yoda on The Tonight Show with @jayleno http://t.co/378jd2ABBN",
      "expandedUrl" : "https://twitter.com/i/web/status/431849778318557184"
    }
  },
  {
    "like" : {
      "tweetId" : "431472850742956033",
      "fullText" : "The Berenstain Bears Do Reprehensible Things To Stay Alive, Because This World Is The Shadow Of Another And So That Is The Only Path To Take",
      "expandedUrl" : "https://twitter.com/i/web/status/431472850742956033"
    }
  },
  {
    "like" : {
      "tweetId" : "431913192281747457",
      "fullText" : "@buerstemple DO NOT",
      "expandedUrl" : "https://twitter.com/i/web/status/431913192281747457"
    }
  },
  {
    "like" : {
      "tweetId" : "432013936154509312",
      "fullText" : "russell brand is incredibly creepy",
      "expandedUrl" : "https://twitter.com/i/web/status/432013936154509312"
    }
  },
  {
    "like" : {
      "tweetId" : "431862591682408448",
      "fullText" : "how will i pass the time",
      "expandedUrl" : "https://twitter.com/i/web/status/431862591682408448"
    }
  },
  {
    "like" : {
      "tweetId" : "432010740237492224",
      "fullText" : "@brostitute ah yes, we all have our #WhopperRegrets",
      "expandedUrl" : "https://twitter.com/i/web/status/432010740237492224"
    }
  },
  {
    "like" : {
      "tweetId" : "431907887376396288",
      "fullText" : "@starkyy_ yeah its pretty fun but girls get to use all sorts of dildos i think thats pretty cool too",
      "expandedUrl" : "https://twitter.com/i/web/status/431907887376396288"
    }
  },
  {
    "like" : {
      "tweetId" : "431898695752101888",
      "fullText" : "my teacher is heimerdinger http://t.co/JuBZAz0rZg",
      "expandedUrl" : "https://twitter.com/i/web/status/431898695752101888"
    }
  },
  {
    "like" : {
      "tweetId" : "432017882055057408",
      "fullText" : "Queeblo 001 - Whopper and a Forty: http://t.co/ApLARz66jv",
      "expandedUrl" : "https://twitter.com/i/web/status/432017882055057408"
    }
  },
  {
    "like" : {
      "tweetId" : "431896685501890561",
      "fullText" : "what. the fuck",
      "expandedUrl" : "https://twitter.com/i/web/status/431896685501890561"
    }
  },
  {
    "like" : {
      "tweetId" : "430986771099160577",
      "fullText" : "George Zimmerman will fight rapper DMX in 3-round boxing match, \"celebrity boxing\" promoter said. http://t.co/gE6yxcxIrb",
      "expandedUrl" : "https://twitter.com/i/web/status/430986771099160577"
    }
  },
  {
    "like" : {
      "tweetId" : "431862546866266112",
      "fullText" : "HUH. TWO MORE HOURS UNTIL CLASS",
      "expandedUrl" : "https://twitter.com/i/web/status/431862546866266112"
    }
  },
  {
    "like" : {
      "tweetId" : "431903852443336704",
      "fullText" : "@starkyy_ yes",
      "expandedUrl" : "https://twitter.com/i/web/status/431903852443336704"
    }
  },
  {
    "like" : {
      "tweetId" : "431901668704129025",
      "fullText" : "@SpaceJordan THATS A LOT",
      "expandedUrl" : "https://twitter.com/i/web/status/431901668704129025"
    }
  },
  {
    "like" : {
      "tweetId" : "432045338065506304",
      "fullText" : "@PrtScnSysRq hows it goin persy",
      "expandedUrl" : "https://twitter.com/i/web/status/432045338065506304"
    }
  },
  {
    "like" : {
      "tweetId" : "432057513404424192",
      "fullText" : "\"No \"code\" is getting into his system, only heavy metals and poisonous polymers.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/432057513404424192"
    }
  },
  {
    "like" : {
      "tweetId" : "432057231966629889",
      "fullText" : "\"I thought this thread would be about a small child, not a grown-ass man.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/432057231966629889"
    }
  },
  {
    "like" : {
      "tweetId" : "432043205509398529",
      "fullText" : "@xsolus i fucking love vague and shitty philosophical sayings",
      "expandedUrl" : "https://twitter.com/i/web/status/432043205509398529"
    }
  },
  {
    "like" : {
      "tweetId" : "432057573424918529",
      "fullText" : "ABSORB COMPUTER CODE THROUGH DIGESTION",
      "expandedUrl" : "https://twitter.com/i/web/status/432057573424918529"
    }
  },
  {
    "like" : {
      "tweetId" : "432033273363980288",
      "fullText" : "@captaindangus epic",
      "expandedUrl" : "https://twitter.com/i/web/status/432033273363980288"
    }
  },
  {
    "like" : {
      "tweetId" : "432056998209671168",
      "fullText" : "\"I'm going to swallow this Ocarina of Time cartridge and absorb the powers of the Legend of Zelda.\" flawless logic",
      "expandedUrl" : "https://twitter.com/i/web/status/432056998209671168"
    }
  },
  {
    "like" : {
      "tweetId" : "432057312811823104",
      "fullText" : "@Garufyne thats a good album, though i do like the orchestra album a bit more",
      "expandedUrl" : "https://twitter.com/i/web/status/432057312811823104"
    }
  },
  {
    "like" : {
      "tweetId" : "432041473106665472",
      "fullText" : "@xsolus things are never easy in the beginning",
      "expandedUrl" : "https://twitter.com/i/web/status/432041473106665472"
    }
  },
  {
    "like" : {
      "tweetId" : "432040155424108544",
      "fullText" : "convulse http://t.co/W9ackNn7Ie",
      "expandedUrl" : "https://twitter.com/i/web/status/432040155424108544"
    }
  },
  {
    "like" : {
      "tweetId" : "432043415698558977",
      "fullText" : "i only have one friend on facebook who likes steve blum.",
      "expandedUrl" : "https://twitter.com/i/web/status/432043415698558977"
    }
  },
  {
    "like" : {
      "tweetId" : "432030628326805504",
      "fullText" : "@syrupf a really strong push",
      "expandedUrl" : "https://twitter.com/i/web/status/432030628326805504"
    }
  },
  {
    "like" : {
      "tweetId" : "432043521927696384",
      "fullText" : "@Lolibooru your team is op though",
      "expandedUrl" : "https://twitter.com/i/web/status/432043521927696384"
    }
  },
  {
    "like" : {
      "tweetId" : "432027777122848768",
      "fullText" : "it is clear to me that my online course has not been updated in seven years. understandable, but depressing",
      "expandedUrl" : "https://twitter.com/i/web/status/432027777122848768"
    }
  },
  {
    "like" : {
      "tweetId" : "432054801514250240",
      "fullText" : "Dip Oreos in Bailey's...",
      "expandedUrl" : "https://twitter.com/i/web/status/432054801514250240"
    }
  },
  {
    "like" : {
      "tweetId" : "432056103422021632",
      "fullText" : "Presented without commentary. http://t.co/HNhMn7ebRm",
      "expandedUrl" : "https://twitter.com/i/web/status/432056103422021632"
    }
  },
  {
    "like" : {
      "tweetId" : "432050209086914560",
      "fullText" : "KNOCK KNOCK ITS KNUCKLES",
      "expandedUrl" : "https://twitter.com/i/web/status/432050209086914560"
    }
  },
  {
    "like" : {
      "tweetId" : "432027868495749120",
      "fullText" : "@Lolibooru that kid is a goddamn legend",
      "expandedUrl" : "https://twitter.com/i/web/status/432027868495749120"
    }
  },
  {
    "like" : {
      "tweetId" : "432039339132866560",
      "fullText" : "@JustAboutGlad at least its not your dying room",
      "expandedUrl" : "https://twitter.com/i/web/status/432039339132866560"
    }
  },
  {
    "like" : {
      "tweetId" : "432050287360999425",
      "fullText" : "@_crazziquai_ https://t.co/qAgcoyWQxF",
      "expandedUrl" : "https://twitter.com/i/web/status/432050287360999425"
    }
  },
  {
    "like" : {
      "tweetId" : "432057359712522241",
      "fullText" : "\"This is some frightening cultist shit.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/432057359712522241"
    }
  },
  {
    "like" : {
      "tweetId" : "432065028536016896",
      "fullText" : "@Lolibooru SMOOCH",
      "expandedUrl" : "https://twitter.com/i/web/status/432065028536016896"
    }
  },
  {
    "like" : {
      "tweetId" : "432051744676139008",
      "fullText" : "@PrtScnSysRq goodnight!",
      "expandedUrl" : "https://twitter.com/i/web/status/432051744676139008"
    }
  },
  {
    "like" : {
      "tweetId" : "432036988883976192",
      "fullText" : "wario hide the weed",
      "expandedUrl" : "https://twitter.com/i/web/status/432036988883976192"
    }
  },
  {
    "like" : {
      "tweetId" : "432042806970830848",
      "fullText" : "http://t.co/iFrMvLDAfz",
      "expandedUrl" : "https://twitter.com/i/web/status/432042806970830848"
    }
  },
  {
    "like" : {
      "tweetId" : "339501866239012864",
      "fullText" : "@ihadtopee I'm living so Dry right now. My Camaro is lacking a door.",
      "expandedUrl" : "https://twitter.com/i/web/status/339501866239012864"
    }
  },
  {
    "like" : {
      "tweetId" : "366520092479062019",
      "fullText" : "@ihadtopee Carp.",
      "expandedUrl" : "https://twitter.com/i/web/status/366520092479062019"
    }
  },
  {
    "like" : {
      "tweetId" : "293000926703255552",
      "fullText" : "@ihadtopee Mind over sheepdog.",
      "expandedUrl" : "https://twitter.com/i/web/status/293000926703255552"
    }
  },
  {
    "like" : {
      "tweetId" : "432073957210996737",
      "fullText" : "You're my new obsession",
      "expandedUrl" : "https://twitter.com/i/web/status/432073957210996737"
    }
  },
  {
    "like" : {
      "tweetId" : "278360047610888192",
      "fullText" : "@ihadtopee Don’t worry, we’re only going to pillage forty two percent of the population.",
      "expandedUrl" : "https://twitter.com/i/web/status/278360047610888192"
    }
  },
  {
    "like" : {
      "tweetId" : "372599098358366208",
      "fullText" : "@ihadtopee Shatter the glass of sorrow with a ping-pong ball.",
      "expandedUrl" : "https://twitter.com/i/web/status/372599098358366208"
    }
  },
  {
    "like" : {
      "tweetId" : "295543514786328576",
      "fullText" : "@ihadtopee If you’re talking the hardest, don’t fuck a sheep with a goat in a glass lift.",
      "expandedUrl" : "https://twitter.com/i/web/status/295543514786328576"
    }
  },
  {
    "like" : {
      "tweetId" : "346108107098820608",
      "fullText" : "http://t.co/WPP8cydcwY got an old Mercedes diesel  #Europeanautos @ihadtopee",
      "expandedUrl" : "https://twitter.com/i/web/status/346108107098820608"
    }
  },
  {
    "like" : {
      "tweetId" : "294277448412057600",
      "fullText" : "http://t.co/z7MZUDNj",
      "expandedUrl" : "https://twitter.com/i/web/status/294277448412057600"
    }
  },
  {
    "like" : {
      "tweetId" : "294213898918309888",
      "fullText" : "While back I mocked Frangipan. But today a six foot rectangle of Frangipan appeared silently at the end of my bed. An almondy slab of dread.",
      "expandedUrl" : "https://twitter.com/i/web/status/294213898918309888"
    }
  },
  {
    "like" : {
      "tweetId" : "297466532877979648",
      "fullText" : "@ihadtopee This is the winter of your baby eating sheep.",
      "expandedUrl" : "https://twitter.com/i/web/status/297466532877979648"
    }
  },
  {
    "like" : {
      "tweetId" : "326202019335503872",
      "fullText" : "@ihadtopee Kum buy sheep music for Salvation Army shoppers.",
      "expandedUrl" : "https://twitter.com/i/web/status/326202019335503872"
    }
  },
  {
    "like" : {
      "tweetId" : "312936159401619456",
      "fullText" : "@ihadtopee Pina Colada toothbrush.",
      "expandedUrl" : "https://twitter.com/i/web/status/312936159401619456"
    }
  },
  {
    "like" : {
      "tweetId" : "432074034063233025",
      "fullText" : "I have a ton of music material to go over tomorrow. Goodnight",
      "expandedUrl" : "https://twitter.com/i/web/status/432074034063233025"
    }
  },
  {
    "like" : {
      "tweetId" : "294280785698103296",
      "fullText" : "in the future ther will be no more celebritys just holograms of old ones",
      "expandedUrl" : "https://twitter.com/i/web/status/294280785698103296"
    }
  },
  {
    "like" : {
      "tweetId" : "277971580359938049",
      "fullText" : "I got about 1,000 DM's in my inbox. About 20 are real...",
      "expandedUrl" : "https://twitter.com/i/web/status/277971580359938049"
    }
  },
  {
    "like" : {
      "tweetId" : "294198614308315137",
      "fullText" : ".@NASA why arent we in space now.",
      "expandedUrl" : "https://twitter.com/i/web/status/294198614308315137"
    }
  },
  {
    "like" : {
      "tweetId" : "313749616900317184",
      "fullText" : "@ihadtopee It’s Tweenies Total Wipeout.",
      "expandedUrl" : "https://twitter.com/i/web/status/313749616900317184"
    }
  },
  {
    "like" : {
      "tweetId" : "278359516997881856",
      "fullText" : "@ihadtopee http://t.co/RKIsA7Sx",
      "expandedUrl" : "https://twitter.com/i/web/status/278359516997881856"
    }
  },
  {
    "like" : {
      "tweetId" : "354070715965792256",
      "fullText" : "Got a dry benz u need to se it runs on the fule of the devil and it is claterly and slow as an old beatle  @ihadtopee http://t.co/uQUXoxOHWD",
      "expandedUrl" : "https://twitter.com/i/web/status/354070715965792256"
    }
  },
  {
    "like" : {
      "tweetId" : "294200334467862528",
      "fullText" : "iM GUNNA GET A CANDY COATED CRUiSE SHiP AND THEN THROW MY PHONE iN THE WATER AND START SAiLiNG AROUND THE WORLD BECUZ i NEED A VACATiON",
      "expandedUrl" : "https://twitter.com/i/web/status/294200334467862528"
    }
  },
  {
    "like" : {
      "tweetId" : "278361805049438208",
      "fullText" : "@ihadtopee Yay! Hadron Collider.",
      "expandedUrl" : "https://twitter.com/i/web/status/278361805049438208"
    }
  },
  {
    "like" : {
      "tweetId" : "278365352386244608",
      "fullText" : "@ihadtopee Fizzy-moon.",
      "expandedUrl" : "https://twitter.com/i/web/status/278365352386244608"
    }
  },
  {
    "like" : {
      "tweetId" : "321363201268793344",
      "fullText" : "@ihadtopee Operation Horse Radish Underwear is bad for you.",
      "expandedUrl" : "https://twitter.com/i/web/status/321363201268793344"
    }
  },
  {
    "like" : {
      "tweetId" : "330124748640120835",
      "fullText" : "Im over here like Walter Murch",
      "expandedUrl" : "https://twitter.com/i/web/status/330124748640120835"
    }
  },
  {
    "like" : {
      "tweetId" : "277972942271414272",
      "fullText" : "------&gt; RT @SoItsMiyah: Basketball is the biggest stress reliever.",
      "expandedUrl" : "https://twitter.com/i/web/status/277972942271414272"
    }
  },
  {
    "like" : {
      "tweetId" : "277972244129521665",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible @_MarciaPerea",
      "expandedUrl" : "https://twitter.com/i/web/status/277972244129521665"
    }
  },
  {
    "like" : {
      "tweetId" : "277972252111298560",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible 1) @lizhet_28 mi flaquita :3 te amo",
      "expandedUrl" : "https://twitter.com/i/web/status/277972252111298560"
    }
  },
  {
    "like" : {
      "tweetId" : "277972237833875458",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible Gab Amadeo, gracias por tantas sonrisas",
      "expandedUrl" : "https://twitter.com/i/web/status/277972237833875458"
    }
  },
  {
    "like" : {
      "tweetId" : "277972232570015744",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible @AlexArteaga96 te amo gordo ! Gracias por siempre acerme sentir bien cuando estoy triste! :*",
      "expandedUrl" : "https://twitter.com/i/web/status/277972232570015744"
    }
  },
  {
    "like" : {
      "tweetId" : "277972845697576960",
      "fullText" : "is that a number",
      "expandedUrl" : "https://twitter.com/i/web/status/277972845697576960"
    }
  },
  {
    "like" : {
      "tweetId" : "277972232964300800",
      "fullText" : "N.11 @onedirection  #20PersonasQueHicieronDeMi2012AlgoIncreible",
      "expandedUrl" : "https://twitter.com/i/web/status/277972232964300800"
    }
  },
  {
    "like" : {
      "tweetId" : "277972243353579521",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible la ailu, te amoooo",
      "expandedUrl" : "https://twitter.com/i/web/status/277972243353579521"
    }
  },
  {
    "like" : {
      "tweetId" : "277972228992286720",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible Los 11 vinotinto, Hugo Chavez, mis 2 hermanos. Mama &lt;3, Papa. #yaya",
      "expandedUrl" : "https://twitter.com/i/web/status/277972228992286720"
    }
  },
  {
    "like" : {
      "tweetId" : "277972789074460672",
      "fullText" : "8̧͈͕̤̞͖̳̯̰̪̲̹̺͙̤̳̠̻ͮ̈́̇̎ͣ͐̇ͤ̔ͯ̉͂̎ͬ̈́̅̚͜8̨̨̞̙͓̱̯͈̫̓̾ͦ͑͟8̨̡̣͉͚̦͇̠̺̘͈͍͗͊͆̄ͧ͂ͩͪ̄̂ͥ͊̃̽͂ͧͅͅ4̴̨̰̬̝͈̦̗͖͇̬ͮ̄̽̍ͯ̌̽͌ͣͤ̀͜͠",
      "expandedUrl" : "https://twitter.com/i/web/status/277972789074460672"
    }
  },
  {
    "like" : {
      "tweetId" : "277972171534524416",
      "fullText" : "Calgary 2008 BMW X3 3 0i SAV All Wheel Drive - $24900   Dealer OOP: Location: Dealer OOP http://t.co/bZ2Jd6N1",
      "expandedUrl" : "https://twitter.com/i/web/status/277972171534524416"
    }
  },
  {
    "like" : {
      "tweetId" : "277972864437735425",
      "fullText" : "I am a number station",
      "expandedUrl" : "https://twitter.com/i/web/status/277972864437735425"
    }
  },
  {
    "like" : {
      "tweetId" : "277972643158847488",
      "fullText" : "yyyyytiiiiii",
      "expandedUrl" : "https://twitter.com/i/web/status/277972643158847488"
    }
  },
  {
    "like" : {
      "tweetId" : "277972233283043328",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible @AnitaCarrere @soficolla @MariaEmiliaRios @PaulitaAlonso97 @julietatorrent las amoooo, gracias!",
      "expandedUrl" : "https://twitter.com/i/web/status/277972233283043328"
    }
  },
  {
    "like" : {
      "tweetId" : "277972174785097728",
      "fullText" : "Calgary 4 Winter Tires used less than 1000 Km - $480   Calgary: 4 Hancook Optimo H 725A Winter radial tires (NOT... http://t.co/axiUKyj9",
      "expandedUrl" : "https://twitter.com/i/web/status/277972174785097728"
    }
  },
  {
    "like" : {
      "tweetId" : "277972172394344448",
      "fullText" : "Calgary 2006 Buick Lucerne CXL Sedan - $10888   Ninth avenue auto  calgary ab: 2006 Buick Lucerne CXL Sedan\nPric... http://t.co/Z7wRY0pl",
      "expandedUrl" : "https://twitter.com/i/web/status/277972172394344448"
    }
  },
  {
    "like" : {
      "tweetId" : "277972239842934785",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible nose!!",
      "expandedUrl" : "https://twitter.com/i/web/status/277972239842934785"
    }
  },
  {
    "like" : {
      "tweetId" : "277972252329398272",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible @andrea_lunah",
      "expandedUrl" : "https://twitter.com/i/web/status/277972252329398272"
    }
  },
  {
    "like" : {
      "tweetId" : "277972252484571136",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible @DayanaraNq",
      "expandedUrl" : "https://twitter.com/i/web/status/277972252484571136"
    }
  },
  {
    "like" : {
      "tweetId" : "277972242225319936",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible @NiallOfficial",
      "expandedUrl" : "https://twitter.com/i/web/status/277972242225319936"
    }
  },
  {
    "like" : {
      "tweetId" : "277972246490935296",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreíble n-8 OrianaDenice@odhc_24",
      "expandedUrl" : "https://twitter.com/i/web/status/277972246490935296"
    }
  },
  {
    "like" : {
      "tweetId" : "277972173132550144",
      "fullText" : "Calgary 2010 Honda CR-V EX 4WD SUV URGENT: URGENT!! Anyone who`s interested to take over my financing, you won`t... http://t.co/TCuSoSfo",
      "expandedUrl" : "https://twitter.com/i/web/status/277972173132550144"
    }
  },
  {
    "like" : {
      "tweetId" : "277972242577637376",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreíble @LaTerreros  :)",
      "expandedUrl" : "https://twitter.com/i/web/status/277972242577637376"
    }
  },
  {
    "like" : {
      "tweetId" : "277972233509543936",
      "fullText" : "#20PersonasQueHicieronDeMi2012AlgoIncreible todos los que dejaron una marca en mi vida! ya sea con algo malo o bueno, de todo se aprende :D",
      "expandedUrl" : "https://twitter.com/i/web/status/277972233509543936"
    }
  },
  {
    "like" : {
      "tweetId" : "277972923506114560",
      "fullText" : "88488488838203498702934750293485702349857203948572039845720394875023948572039457203948573094572034161345612300238687298477501038831096720987",
      "expandedUrl" : "https://twitter.com/i/web/status/277972923506114560"
    }
  },
  {
    "like" : {
      "tweetId" : "277969234737389569",
      "fullText" : "if Justin comes to Kansas, Nebraska, or Iowa I will shit my pants. asdfghklgdfkli please dear lord.",
      "expandedUrl" : "https://twitter.com/i/web/status/277969234737389569"
    }
  },
  {
    "like" : {
      "tweetId" : "277969180559560704",
      "fullText" : "@DylanHeckert Please come to Iowa I really want to meet you!!(:",
      "expandedUrl" : "https://twitter.com/i/web/status/277969180559560704"
    }
  },
  {
    "like" : {
      "tweetId" : "277972989541244928",
      "fullText" : "you're never alone",
      "expandedUrl" : "https://twitter.com/i/web/status/277972989541244928"
    }
  },
  {
    "like" : {
      "tweetId" : "276762067615223808",
      "fullText" : "@myidal We need people to be in the next Weezy video click on @ExtrasNeeded and simply follow the directions",
      "expandedUrl" : "https://twitter.com/i/web/status/276762067615223808"
    }
  },
  {
    "like" : {
      "tweetId" : "277969723545772032",
      "fullText" : "@ShaforostovD loved ur video dude. @mattthepanda and i love u lots. Excited for ur new band! Remember us here in iowa! :)",
      "expandedUrl" : "https://twitter.com/i/web/status/277969723545772032"
    }
  },
  {
    "like" : {
      "tweetId" : "277968983439859712",
      "fullText" : "The tree is up. Iowa Christmas food eaten. Manhattan beach fireworks ready to start. @BeauBedford &amp; the Texas Gentleman almost here. #bliss",
      "expandedUrl" : "https://twitter.com/i/web/status/277968983439859712"
    }
  },
  {
    "like" : {
      "tweetId" : "277877943483654144",
      "fullText" : "#DL Lil B - \"Glassface\" #MIXTAPE 28 BRAND NEW TRACKS! EVERY ONE IS #RARE AND #BASED http://t.co/addLbKMN DOWNLOAD HISTORICAL TAPE! - Lil B",
      "expandedUrl" : "https://twitter.com/i/web/status/277877943483654144"
    }
  },
  {
    "like" : {
      "tweetId" : "277969526623191040",
      "fullText" : "@MattCarrillo27 lol, wrong. they must have migrated up to Iowa. They may have originated in mville.",
      "expandedUrl" : "https://twitter.com/i/web/status/277969526623191040"
    }
  },
  {
    "like" : {
      "tweetId" : "277968997931171841",
      "fullText" : "The love &amp;support from my Iowa all star family is unreal. You guys truly are making it easier for us. I don't know what I would with out you",
      "expandedUrl" : "https://twitter.com/i/web/status/277968997931171841"
    }
  },
  {
    "like" : {
      "tweetId" : "273352980504408064",
      "fullText" : "Super 3D Noah's Ark: A Fast Moving, Action-Packed Adventure Aboard Noah's Ark!  http://t.co/c8w25ets via @amazon",
      "expandedUrl" : "https://twitter.com/i/web/status/273352980504408064"
    }
  },
  {
    "like" : {
      "tweetId" : "277973149348417536",
      "fullText" : "pooping",
      "expandedUrl" : "https://twitter.com/i/web/status/277973149348417536"
    }
  },
  {
    "like" : {
      "tweetId" : "277466953642307584",
      "fullText" : "http://t.co/apONuNoo",
      "expandedUrl" : "https://twitter.com/i/web/status/277466953642307584"
    }
  },
  {
    "like" : {
      "tweetId" : "277969647654027265",
      "fullText" : "Jst got the mail I needed, from iowa western, when I make it big if I ont fck wit chu now trust me I won't then!",
      "expandedUrl" : "https://twitter.com/i/web/status/277969647654027265"
    }
  },
  {
    "like" : {
      "tweetId" : "277464270248235008",
      "fullText" : "New Study Finds Conclusive Link Between Video Game Use and Violence - http://t.co/0InFEBeJ #Patapon #PSP @PlayStation",
      "expandedUrl" : "https://twitter.com/i/web/status/277464270248235008"
    }
  },
  {
    "like" : {
      "tweetId" : "277969196997025792",
      "fullText" : "Iowa State roars to early lead, whips Nebraska-Omaha 93-65 - Washington Post http://t.co/OksubFsA",
      "expandedUrl" : "https://twitter.com/i/web/status/277969196997025792"
    }
  },
  {
    "like" : {
      "tweetId" : "277968926904811521",
      "fullText" : "@justinbieber get your ass to iowa before i shoot someone this is not ok",
      "expandedUrl" : "https://twitter.com/i/web/status/277968926904811521"
    }
  },
  {
    "like" : {
      "tweetId" : "277968842473488385",
      "fullText" : "@njacob18 I haven't ben 2 Iowa city but am sure tht am gonna love it like some big O titties, once Kendrick arrives he will show it no pity!",
      "expandedUrl" : "https://twitter.com/i/web/status/277968842473488385"
    }
  },
  {
    "like" : {
      "tweetId" : "277972944121114624",
      "fullText" : "Freezing rain. Not only has Winter arrived but in the worst form possible.",
      "expandedUrl" : "https://twitter.com/i/web/status/277972944121114624"
    }
  },
  {
    "like" : {
      "tweetId" : "277973166733787136",
      "fullText" : "Innovative Driving Program: A new concept is now available that rewards consumers who advertise for l... http://t.co/vdAeEnLl #job #blog",
      "expandedUrl" : "https://twitter.com/i/web/status/277973166733787136"
    }
  },
  {
    "like" : {
      "tweetId" : "276378526016483328",
      "fullText" : "Wow. There's not a single Mike Rowe ebooks account.",
      "expandedUrl" : "https://twitter.com/i/web/status/276378526016483328"
    }
  },
  {
    "like" : {
      "tweetId" : "277972942493728768",
      "fullText" : "04:08: \"Perfect World\" von Gossip",
      "expandedUrl" : "https://twitter.com/i/web/status/277972942493728768"
    }
  },
  {
    "like" : {
      "tweetId" : "277973167501357057",
      "fullText" : "Bachelor Party: Sexy, open minded ladies are needed for upscale bachelor party Wed nite. Cash + tips.... http://t.co/EcSlhEVW #job #blog",
      "expandedUrl" : "https://twitter.com/i/web/status/277973167501357057"
    }
  },
  {
    "like" : {
      "tweetId" : "277968962401210368",
      "fullText" : "@DylanHeckert When are you going to come to Iowa??(:",
      "expandedUrl" : "https://twitter.com/i/web/status/277968962401210368"
    }
  },
  {
    "like" : {
      "tweetId" : "277973168327622656",
      "fullText" : "FU CRAIGSDOUCHELIST (FU): FFFFFFFFFUUUUUUUUUU FFFFFFFFFFFFUUUUUUUUUU FFFFFFFFFFFUUUUUUUUUU FFFFFFFFFF... http://t.co/YbV4QMZ4 #job #blog",
      "expandedUrl" : "https://twitter.com/i/web/status/277973168327622656"
    }
  },
  {
    "like" : {
      "tweetId" : "277973170139578368",
      "fullText" : "Computer Graphics -Part time (Norfolk) http://t.co/J5LVcdZB",
      "expandedUrl" : "https://twitter.com/i/web/status/277973170139578368"
    }
  },
  {
    "like" : {
      "tweetId" : "193170531250483200",
      "fullText" : "LOVE IOWA YOU UNEDUCATED FUCK",
      "expandedUrl" : "https://twitter.com/i/web/status/193170531250483200"
    }
  },
  {
    "like" : {
      "tweetId" : "186545083443712003",
      "fullText" : "@hehu42 Free web hosting - for information send an email to info@tonicskyhosting.com , or visit website",
      "expandedUrl" : "https://twitter.com/i/web/status/186545083443712003"
    }
  },
  {
    "like" : {
      "tweetId" : "188351233810116608",
      "fullText" : "Now following @ihadtopee , Everybody follow up! #FFs",
      "expandedUrl" : "https://twitter.com/i/web/status/188351233810116608"
    }
  },
  {
    "like" : {
      "tweetId" : "189521500074807297",
      "fullText" : "yonkers",
      "expandedUrl" : "https://twitter.com/i/web/status/189521500074807297"
    }
  },
  {
    "like" : {
      "tweetId" : "277970313604640768",
      "fullText" : "#mentionsomeonewho makes you laugh so hard you pee yourself @KelsoWalters :)",
      "expandedUrl" : "https://twitter.com/i/web/status/277970313604640768"
    }
  },
  {
    "like" : {
      "tweetId" : "277969731540103168",
      "fullText" : "Iowa State. #ftw #bowlmania",
      "expandedUrl" : "https://twitter.com/i/web/status/277969731540103168"
    }
  },
  {
    "like" : {
      "tweetId" : "183002660167876608",
      "fullText" : "@ihadtopee TY",
      "expandedUrl" : "https://twitter.com/i/web/status/183002660167876608"
    }
  },
  {
    "like" : {
      "tweetId" : "189521483935137792",
      "fullText" : "Yonkers",
      "expandedUrl" : "https://twitter.com/i/web/status/189521483935137792"
    }
  },
  {
    "like" : {
      "tweetId" : "189553071901245441",
      "fullText" : "@ihadtopee Hello! ~(ôwô)~",
      "expandedUrl" : "https://twitter.com/i/web/status/189553071901245441"
    }
  },
  {
    "like" : {
      "tweetId" : "189521917097672706",
      "fullText" : "I just listened to an entire marvin gaye song while waiting at yonkers",
      "expandedUrl" : "https://twitter.com/i/web/status/189521917097672706"
    }
  },
  {
    "like" : {
      "tweetId" : "193379235182821376",
      "fullText" : "@ihadtopee thx it was my temporary name when i had to remake my account that ended up sticking around for 10 months",
      "expandedUrl" : "https://twitter.com/i/web/status/193379235182821376"
    }
  },
  {
    "like" : {
      "tweetId" : "163045414902308864",
      "fullText" : "@ihadtopee http://he&#x72;&#x65;is&#x74;he&#x77;e&#x62;site&#x2E;&#x69;&#x6E;f&#x6F; ?85rL359eh",
      "expandedUrl" : "https://twitter.com/i/web/status/163045414902308864"
    }
  },
  {
    "like" : {
      "tweetId" : "189520733288927232",
      "fullText" : "I'M IN YONKERS",
      "expandedUrl" : "https://twitter.com/i/web/status/189520733288927232"
    }
  },
  {
    "like" : {
      "tweetId" : "197007794585612288",
      "fullText" : "@smcmidmo follow @ihadtopee",
      "expandedUrl" : "https://twitter.com/i/web/status/197007794585612288"
    }
  },
  {
    "like" : {
      "tweetId" : "189521640512688128",
      "fullText" : "yONKERS",
      "expandedUrl" : "https://twitter.com/i/web/status/189521640512688128"
    }
  },
  {
    "like" : {
      "tweetId" : "277970303546703872",
      "fullText" : "TMI &amp; Nope • think you are all alone there! #sadpervert lol\nRT @Coastiefish: Anyone else feel like a pervert when they watch their dog pee?",
      "expandedUrl" : "https://twitter.com/i/web/status/277970303546703872"
    }
  },
  {
    "like" : {
      "tweetId" : "189439259114090497",
      "fullText" : "@ihadtopee AY THANKS NIGGA U MY FAVORITE CLASSIC ROCK BAND",
      "expandedUrl" : "https://twitter.com/i/web/status/189439259114090497"
    }
  },
  {
    "like" : {
      "tweetId" : "186545000576856065",
      "fullText" : "Sext: You are a static jpg. I open you up, hard, and fill you with color and make you move. Youre released into the world a horny GIF",
      "expandedUrl" : "https://twitter.com/i/web/status/186545000576856065"
    }
  },
  {
    "like" : {
      "tweetId" : "189521460975509504",
      "fullText" : "why are we stopped at yonkers",
      "expandedUrl" : "https://twitter.com/i/web/status/189521460975509504"
    }
  },
  {
    "like" : {
      "tweetId" : "164083380152041472",
      "fullText" : "Wtf",
      "expandedUrl" : "https://twitter.com/i/web/status/164083380152041472"
    }
  },
  {
    "like" : {
      "tweetId" : "190451936435249152",
      "fullText" : "#MostOverratedMusicArtists anyone who is not @ihadtopee or @RoobiePhawls",
      "expandedUrl" : "https://twitter.com/i/web/status/190451936435249152"
    }
  },
  {
    "like" : {
      "tweetId" : "188857983134990337",
      "fullText" : "The Funger Games? LOL XD",
      "expandedUrl" : "https://twitter.com/i/web/status/188857983134990337"
    }
  },
  {
    "like" : {
      "tweetId" : "277970294742851585",
      "fullText" : "@Donnie_Pee niggas having beef patties",
      "expandedUrl" : "https://twitter.com/i/web/status/277970294742851585"
    }
  },
  {
    "like" : {
      "tweetId" : "189769205757915137",
      "fullText" : "@ihadtopee HIGH JIMMI HENDRIX *",
      "expandedUrl" : "https://twitter.com/i/web/status/189769205757915137"
    }
  },
  {
    "like" : {
      "tweetId" : "277652852971802624",
      "fullText" : "After that performance by Marquez, I'ma start drinkin my own pee!",
      "expandedUrl" : "https://twitter.com/i/web/status/277652852971802624"
    }
  },
  {
    "like" : {
      "tweetId" : "151066086358519808",
      "fullText" : "@ihadtopee That makes sense That makes sense That makes sense That makes sense That makes sense That makes sense That makes sense That makes",
      "expandedUrl" : "https://twitter.com/i/web/status/151066086358519808"
    }
  },
  {
    "like" : {
      "tweetId" : "428196072725286912",
      "fullText" : "@PersonTheHumann unless you want more expensive studio shit...then get studio monitors.",
      "expandedUrl" : "https://twitter.com/i/web/status/428196072725286912"
    }
  },
  {
    "like" : {
      "tweetId" : "428197847939293186",
      "fullText" : "My truck is a source of time distortion and quantum radiation.",
      "expandedUrl" : "https://twitter.com/i/web/status/428197847939293186"
    }
  },
  {
    "like" : {
      "tweetId" : "429235647606308865",
      "fullText" : "same http://t.co/c1yeNUkBrj",
      "expandedUrl" : "https://twitter.com/i/web/status/429235647606308865"
    }
  },
  {
    "like" : {
      "tweetId" : "429231388420612097",
      "fullText" : "@Collin__P http://t.co/urNKjePRNr",
      "expandedUrl" : "https://twitter.com/i/web/status/429231388420612097"
    }
  },
  {
    "like" : {
      "tweetId" : "428193761491812354",
      "fullText" : "How is it that I knew the iPhone 5c was inevitably going to fail but apple didn't.",
      "expandedUrl" : "https://twitter.com/i/web/status/428193761491812354"
    }
  },
  {
    "like" : {
      "tweetId" : "428157236179775488",
      "fullText" : "instead of sleeping I played the video game",
      "expandedUrl" : "https://twitter.com/i/web/status/428157236179775488"
    }
  },
  {
    "like" : {
      "tweetId" : "428131081917710336",
      "fullText" : "hi2",
      "expandedUrl" : "https://twitter.com/i/web/status/428131081917710336"
    }
  },
  {
    "like" : {
      "tweetId" : "428197769501626368",
      "fullText" : "My Toyota truck is actually a time machine no mechanic has ever gotten a linear odometer reading from it.",
      "expandedUrl" : "https://twitter.com/i/web/status/428197769501626368"
    }
  },
  {
    "like" : {
      "tweetId" : "428195964965236737",
      "fullText" : "@PersonTheHumann I'd just buy a set of PC speakers (with small sub) and an adapter from RCA to 3.5",
      "expandedUrl" : "https://twitter.com/i/web/status/428195964965236737"
    }
  },
  {
    "like" : {
      "tweetId" : "428198613085204480",
      "fullText" : "Fuckable plebe",
      "expandedUrl" : "https://twitter.com/i/web/status/428198613085204480"
    }
  },
  {
    "like" : {
      "tweetId" : "428198370646061056",
      "fullText" : "@PersonTheHumann idk you might have to ask rusk",
      "expandedUrl" : "https://twitter.com/i/web/status/428198370646061056"
    }
  },
  {
    "like" : {
      "tweetId" : "1360040713799532551",
      "fullText" : "Whitney Houston &amp; CeCe Winans - Count On Me",
      "expandedUrl" : "https://twitter.com/i/web/status/1360040713799532551"
    }
  },
  {
    "like" : {
      "tweetId" : "428179939813126144",
      "fullText" : "@ruskimalooski ducks",
      "expandedUrl" : "https://twitter.com/i/web/status/428179939813126144"
    }
  },
  {
    "like" : {
      "tweetId" : "428198007863914496",
      "fullText" : "@peta fuck me in the ass",
      "expandedUrl" : "https://twitter.com/i/web/status/428198007863914496"
    }
  },
  {
    "like" : {
      "tweetId" : "428198668093501440",
      "fullText" : "@MomMilitia sleep",
      "expandedUrl" : "https://twitter.com/i/web/status/428198668093501440"
    }
  },
  {
    "like" : {
      "tweetId" : "428139641657499649",
      "fullText" : "Hello. Today I have to go back to work again. I'm slitting my wrists.",
      "expandedUrl" : "https://twitter.com/i/web/status/428139641657499649"
    }
  },
  {
    "like" : {
      "tweetId" : "494004570105081856",
      "fullText" : "Free solutions is out! http://t.co/DhafyDpgaM Stories via @ZekeQuezada @ihadtopee @buyfollowgain",
      "expandedUrl" : "https://twitter.com/i/web/status/494004570105081856"
    }
  },
  {
    "like" : {
      "tweetId" : "428160397095362562",
      "fullText" : "imagine playing a game where you need to \"attend\" what amounts to a post-secondary school to effectively play it.  Eve Online.",
      "expandedUrl" : "https://twitter.com/i/web/status/428160397095362562"
    }
  },
  {
    "like" : {
      "tweetId" : "428179475990196225",
      "fullText" : "@ruskimalooski what does it say when it overheats?",
      "expandedUrl" : "https://twitter.com/i/web/status/428179475990196225"
    }
  },
  {
    "like" : {
      "tweetId" : "428180357876174848",
      "fullText" : "My cool new shotgun mic will be here on Thursday I'll be SHOVING IT IN MY TIGHT ASSHOLE",
      "expandedUrl" : "https://twitter.com/i/web/status/428180357876174848"
    }
  },
  {
    "like" : {
      "tweetId" : "429228371604566016",
      "fullText" : "http://t.co/eBydNP5IGD",
      "expandedUrl" : "https://twitter.com/i/web/status/429228371604566016"
    }
  },
  {
    "like" : {
      "tweetId" : "429228908467089408",
      "fullText" : "@Collin__P boom operator elite",
      "expandedUrl" : "https://twitter.com/i/web/status/429228908467089408"
    }
  },
  {
    "like" : {
      "tweetId" : "1360038860038828033",
      "fullText" : "Whitney Houston - Exhale (Shoop Shoop)",
      "expandedUrl" : "https://twitter.com/i/web/status/1360038860038828033"
    }
  },
  {
    "like" : {
      "tweetId" : "428140566430224384",
      "fullText" : "I think I first played eve in like 2008",
      "expandedUrl" : "https://twitter.com/i/web/status/428140566430224384"
    }
  },
  {
    "like" : {
      "tweetId" : "428194269858234369",
      "fullText" : "Pro marketing advice from davechan: when you are making record profits on your current formula for the foreseeable future, DON'T CHANGE IT",
      "expandedUrl" : "https://twitter.com/i/web/status/428194269858234369"
    }
  },
  {
    "like" : {
      "tweetId" : "428198707897462784",
      "fullText" : "@MomMilitia ok",
      "expandedUrl" : "https://twitter.com/i/web/status/428198707897462784"
    }
  },
  {
    "like" : {
      "tweetId" : "428376046170165248",
      "fullText" : "@Collin__P be the official drywall movie effects studio",
      "expandedUrl" : "https://twitter.com/i/web/status/428376046170165248"
    }
  },
  {
    "like" : {
      "tweetId" : "428376563520790528",
      "fullText" : "Help",
      "expandedUrl" : "https://twitter.com/i/web/status/428376563520790528"
    }
  },
  {
    "like" : {
      "tweetId" : "428309143447826432",
      "fullText" : "@ruskimalooski depends on which class/role you're planning on playing.",
      "expandedUrl" : "https://twitter.com/i/web/status/428309143447826432"
    }
  },
  {
    "like" : {
      "tweetId" : "428410187670491136",
      "fullText" : "I finally figured out the password to my old eve account this is going to be big",
      "expandedUrl" : "https://twitter.com/i/web/status/428410187670491136"
    }
  },
  {
    "like" : {
      "tweetId" : "428644236674613248",
      "fullText" : "Work mom",
      "expandedUrl" : "https://twitter.com/i/web/status/428644236674613248"
    }
  },
  {
    "like" : {
      "tweetId" : "428377392424300547",
      "fullText" : "The biggest moment of my life just happened.",
      "expandedUrl" : "https://twitter.com/i/web/status/428377392424300547"
    }
  },
  {
    "like" : {
      "tweetId" : "428401747006984192",
      "fullText" : "@ruskimalooski like in the interior or for your repair rate?  Or bridge/duty officers?",
      "expandedUrl" : "https://twitter.com/i/web/status/428401747006984192"
    }
  },
  {
    "like" : {
      "tweetId" : "428338534001303552",
      "fullText" : "@PersonTheHumann yeah I guess so. Still very sad about blue car.",
      "expandedUrl" : "https://twitter.com/i/web/status/428338534001303552"
    }
  },
  {
    "like" : {
      "tweetId" : "428198690163945472",
      "fullText" : "@MomMilitia no",
      "expandedUrl" : "https://twitter.com/i/web/status/428198690163945472"
    }
  },
  {
    "like" : {
      "tweetId" : "428314320913440768",
      "fullText" : "@ruskimalooski you can always get another ship though - doesn't matter too much at low level.",
      "expandedUrl" : "https://twitter.com/i/web/status/428314320913440768"
    }
  },
  {
    "like" : {
      "tweetId" : "428375214737461249",
      "fullText" : "@PrtScnSysRq drywall hit",
      "expandedUrl" : "https://twitter.com/i/web/status/428375214737461249"
    }
  },
  {
    "like" : {
      "tweetId" : "428525056902172672",
      "fullText" : "@playsaUceE hi",
      "expandedUrl" : "https://twitter.com/i/web/status/428525056902172672"
    }
  },
  {
    "like" : {
      "tweetId" : "428407918925344768",
      "fullText" : "@ruskimalooski can you get online now?  I can show you",
      "expandedUrl" : "https://twitter.com/i/web/status/428407918925344768"
    }
  },
  {
    "like" : {
      "tweetId" : "428376281550311424",
      "fullText" : "I'm trapped in the bathroom and there's a guy vining",
      "expandedUrl" : "https://twitter.com/i/web/status/428376281550311424"
    }
  },
  {
    "like" : {
      "tweetId" : "428326747709267968",
      "fullText" : "@PersonTheHumann RIP dammit I liked that car.",
      "expandedUrl" : "https://twitter.com/i/web/status/428326747709267968"
    }
  },
  {
    "like" : {
      "tweetId" : "428472384400527360",
      "fullText" : "hello",
      "expandedUrl" : "https://twitter.com/i/web/status/428472384400527360"
    }
  },
  {
    "like" : {
      "tweetId" : "428649090142830592",
      "fullText" : "Tired mom",
      "expandedUrl" : "https://twitter.com/i/web/status/428649090142830592"
    }
  },
  {
    "like" : {
      "tweetId" : "428409382599024640",
      "fullText" : "@ruskimalooski ok scroll to \"Obtaining More Duty Officers\" http://t.co/exL2HWNyIN",
      "expandedUrl" : "https://twitter.com/i/web/status/428409382599024640"
    }
  },
  {
    "like" : {
      "tweetId" : "428376540095590400",
      "fullText" : "Screaming \"I KNOW THIS AINT NO PARTY\" and then macklemore plays.",
      "expandedUrl" : "https://twitter.com/i/web/status/428376540095590400"
    }
  },
  {
    "like" : {
      "tweetId" : "428326005204217856",
      "fullText" : "@PersonTheHumann did other car not work out?",
      "expandedUrl" : "https://twitter.com/i/web/status/428326005204217856"
    }
  },
  {
    "like" : {
      "tweetId" : "428312949594140672",
      "fullText" : "@ruskimalooski I can phosho but I don't get off until 11:15.",
      "expandedUrl" : "https://twitter.com/i/web/status/428312949594140672"
    }
  },
  {
    "like" : {
      "tweetId" : "428314127996448768",
      "fullText" : "@ruskimalooski for you I'd recommend escort because it makes space combat more immediately fun.",
      "expandedUrl" : "https://twitter.com/i/web/status/428314127996448768"
    }
  },
  {
    "like" : {
      "tweetId" : "428375367758270465",
      "fullText" : "New single: \"I'm About to Get Into a Car Accident.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/428375367758270465"
    }
  },
  {
    "like" : {
      "tweetId" : "428314030394982400",
      "fullText" : "@ruskimalooski if you want to do damage, get escort. If you want to take damage and look cool, get whatever cruiser class is offered.",
      "expandedUrl" : "https://twitter.com/i/web/status/428314030394982400"
    }
  },
  {
    "like" : {
      "tweetId" : "428695147723763712",
      "fullText" : "@ruskimalooski probably not until captain or so. (Lvl 40) but good BOs make things go quicker at low level.",
      "expandedUrl" : "https://twitter.com/i/web/status/428695147723763712"
    }
  },
  {
    "like" : {
      "tweetId" : "428653304189820928",
      "fullText" : "@PrtScnSysRq #thing2019 tonight after 10, my house.",
      "expandedUrl" : "https://twitter.com/i/web/status/428653304189820928"
    }
  },
  {
    "like" : {
      "tweetId" : "428820109562368000",
      "fullText" : "shit it's taken http://t.co/WGI3MTZKig",
      "expandedUrl" : "https://twitter.com/i/web/status/428820109562368000"
    }
  },
  {
    "like" : {
      "tweetId" : "428855254742880256",
      "fullText" : "with MMOs anyway",
      "expandedUrl" : "https://twitter.com/i/web/status/428855254742880256"
    }
  },
  {
    "like" : {
      "tweetId" : "428744863555678210",
      "fullText" : "@ruskimalooski @kabeebus @ErzaEllie @FawkMSN @TheThorde @degrett be sure to visit http://t.co/eiuoU6PVpT and donate.",
      "expandedUrl" : "https://twitter.com/i/web/status/428744863555678210"
    }
  },
  {
    "like" : {
      "tweetId" : "429070596480053248",
      "fullText" : "I got my mic but I have to wait to use it",
      "expandedUrl" : "https://twitter.com/i/web/status/429070596480053248"
    }
  },
  {
    "like" : {
      "tweetId" : "428872730910289920",
      "fullText" : "@DrinkingQuest hi",
      "expandedUrl" : "https://twitter.com/i/web/status/428872730910289920"
    }
  },
  {
    "like" : {
      "tweetId" : "428903891032227840",
      "fullText" : "I made windows 7 look like xp",
      "expandedUrl" : "https://twitter.com/i/web/status/428903891032227840"
    }
  },
  {
    "like" : {
      "tweetId" : "429070755758735360",
      "fullText" : "Drywall new PUBLICITY EP being recorded TONIGHT/EARLY TOMORROW MORNING.",
      "expandedUrl" : "https://twitter.com/i/web/status/429070755758735360"
    }
  },
  {
    "like" : {
      "tweetId" : "428676207618433024",
      "fullText" : "@PrtScnSysRq @kabeebus help",
      "expandedUrl" : "https://twitter.com/i/web/status/428676207618433024"
    }
  },
  {
    "like" : {
      "tweetId" : "428710373298941952",
      "fullText" : "Rip pump 1",
      "expandedUrl" : "https://twitter.com/i/web/status/428710373298941952"
    }
  },
  {
    "like" : {
      "tweetId" : "429015040465707008",
      "fullText" : "I can't believe I got the Iowa ticket I'm so happy",
      "expandedUrl" : "https://twitter.com/i/web/status/429015040465707008"
    }
  },
  {
    "like" : {
      "tweetId" : "428663520511918080",
      "fullText" : "@TheEllenShow TELL ME IM A SLUT",
      "expandedUrl" : "https://twitter.com/i/web/status/428663520511918080"
    }
  },
  {
    "like" : {
      "tweetId" : "428649661155377152",
      "fullText" : "Mk v golf gti deep throat",
      "expandedUrl" : "https://twitter.com/i/web/status/428649661155377152"
    }
  },
  {
    "like" : {
      "tweetId" : "428683605208858624",
      "fullText" : "Hello I am at work making that's what she said jokes",
      "expandedUrl" : "https://twitter.com/i/web/status/428683605208858624"
    }
  },
  {
    "like" : {
      "tweetId" : "429019646742638592",
      "fullText" : "I HAVENT SLEPT",
      "expandedUrl" : "https://twitter.com/i/web/status/429019646742638592"
    }
  },
  {
    "like" : {
      "tweetId" : "428855271515897856",
      "fullText" : "I played piano",
      "expandedUrl" : "https://twitter.com/i/web/status/428855271515897856"
    }
  },
  {
    "like" : {
      "tweetId" : "428694775387017217",
      "fullText" : "@ruskimalooski no you should get BOs for free along the way. I also have a SHITLOAD of uncommon and rare BOs if you want them.",
      "expandedUrl" : "https://twitter.com/i/web/status/428694775387017217"
    }
  },
  {
    "like" : {
      "tweetId" : "428652508269907968",
      "fullText" : "My Miata is very kawaii",
      "expandedUrl" : "https://twitter.com/i/web/status/428652508269907968"
    }
  },
  {
    "like" : {
      "tweetId" : "428813397312811008",
      "fullText" : "hello I'm about to do a dumb thing in eve online game",
      "expandedUrl" : "https://twitter.com/i/web/status/428813397312811008"
    }
  },
  {
    "like" : {
      "tweetId" : "428673020329082882",
      "fullText" : "@kabeebus @PrtScnSysRq stop",
      "expandedUrl" : "https://twitter.com/i/web/status/428673020329082882"
    }
  },
  {
    "like" : {
      "tweetId" : "428694252470534144",
      "fullText" : "@ruskimalooski http://t.co/jMPwzaR6Mm",
      "expandedUrl" : "https://twitter.com/i/web/status/428694252470534144"
    }
  },
  {
    "like" : {
      "tweetId" : "429014514936193024",
      "fullText" : "Eve Online corporation: Mom Militia.  Ticker: [IOWA]",
      "expandedUrl" : "https://twitter.com/i/web/status/429014514936193024"
    }
  },
  {
    "like" : {
      "tweetId" : "428855231137345537",
      "fullText" : "if you think about it, CCP has the absolute perfect formula for moneymaking with eve online",
      "expandedUrl" : "https://twitter.com/i/web/status/428855231137345537"
    }
  },
  {
    "like" : {
      "tweetId" : "428904533901574145",
      "fullText" : "the video game",
      "expandedUrl" : "https://twitter.com/i/web/status/428904533901574145"
    }
  },
  {
    "like" : {
      "tweetId" : "430740134158278656",
      "fullText" : "@Collin__P yeah you might want to wait to join to see if it's something you'll want to do",
      "expandedUrl" : "https://twitter.com/i/web/status/430740134158278656"
    }
  },
  {
    "like" : {
      "tweetId" : "430535060245073920",
      "fullText" : "COLLAB WITH @kevjumba - DONATE NOW http://t.co/yGvUQpRQGk",
      "expandedUrl" : "https://twitter.com/i/web/status/430535060245073920"
    }
  },
  {
    "like" : {
      "tweetId" : "429795533381976064",
      "fullText" : "same http://t.co/ByakVcyAlY",
      "expandedUrl" : "https://twitter.com/i/web/status/429795533381976064"
    }
  },
  {
    "like" : {
      "tweetId" : "429852581028835328",
      "fullText" : "@ruskimalooski don't worry rusk, brain to twitter interfaces are comin within our lifetimes.",
      "expandedUrl" : "https://twitter.com/i/web/status/429852581028835328"
    }
  },
  {
    "like" : {
      "tweetId" : "429262710291709952",
      "fullText" : "selfie http://t.co/qGitz4sWnF",
      "expandedUrl" : "https://twitter.com/i/web/status/429262710291709952"
    }
  },
  {
    "like" : {
      "tweetId" : "429263570543443970",
      "fullText" : "Ferris",
      "expandedUrl" : "https://twitter.com/i/web/status/429263570543443970"
    }
  },
  {
    "like" : {
      "tweetId" : "429264572080353281",
      "fullText" : "@ruskimalooski http://t.co/yGvUQpRQGk",
      "expandedUrl" : "https://twitter.com/i/web/status/429264572080353281"
    }
  },
  {
    "like" : {
      "tweetId" : "430779943664885760",
      "fullText" : "I ordered sandwich from jimmy johns and guy came in mitsubishi eclipse in blizzard",
      "expandedUrl" : "https://twitter.com/i/web/status/430779943664885760"
    }
  },
  {
    "like" : {
      "tweetId" : "429262293193330689",
      "fullText" : "@ruskimalooski epic",
      "expandedUrl" : "https://twitter.com/i/web/status/429262293193330689"
    }
  },
  {
    "like" : {
      "tweetId" : "429942076063510528",
      "fullText" : "I can't get itunes to install correctly",
      "expandedUrl" : "https://twitter.com/i/web/status/429942076063510528"
    }
  },
  {
    "like" : {
      "tweetId" : "430517407124180993",
      "fullText" : "@ruskimalooski yeah the image is probably wrong - seems to happen a lot when buying online. My $3000 camera was listed under the wrong pic.",
      "expandedUrl" : "https://twitter.com/i/web/status/430517407124180993"
    }
  },
  {
    "like" : {
      "tweetId" : "430517906183843840",
      "fullText" : "@ruskimalooski dude I'll order like 300 gallons + 7000 rounds of 7.62mm rifle ammo and then talk about killing Barack Obama on twitter",
      "expandedUrl" : "https://twitter.com/i/web/status/430517906183843840"
    }
  },
  {
    "like" : {
      "tweetId" : "429148419496501248",
      "fullText" : "ORANGE JUICE IS BEAUTIFUL",
      "expandedUrl" : "https://twitter.com/i/web/status/429148419496501248"
    }
  },
  {
    "like" : {
      "tweetId" : "430516947655352320",
      "fullText" : "@ruskimalooski NEVER MIND OH FUCK http://t.co/OWngHisgdv",
      "expandedUrl" : "https://twitter.com/i/web/status/430516947655352320"
    }
  },
  {
    "like" : {
      "tweetId" : "429136264445440000",
      "fullText" : "@rkellyfucks not on this release because it's just going to be solo piano improv you can on the next one though",
      "expandedUrl" : "https://twitter.com/i/web/status/429136264445440000"
    }
  },
  {
    "like" : {
      "tweetId" : "430518426344235008",
      "fullText" : "Uh oh.  http://t.co/2fPWP9SlC1",
      "expandedUrl" : "https://twitter.com/i/web/status/430518426344235008"
    }
  },
  {
    "like" : {
      "tweetId" : "429943786274181120",
      "fullText" : "imagine if I did a live stream of me mining in Eve",
      "expandedUrl" : "https://twitter.com/i/web/status/429943786274181120"
    }
  },
  {
    "like" : {
      "tweetId" : "429071264737533953",
      "fullText" : "I should say MAYBE being recorded tonight/tomorrow morning because I am TIRED AS FUCK",
      "expandedUrl" : "https://twitter.com/i/web/status/429071264737533953"
    }
  },
  {
    "like" : {
      "tweetId" : "429852262702120961",
      "fullText" : "I want an elephant friend.",
      "expandedUrl" : "https://twitter.com/i/web/status/429852262702120961"
    }
  },
  {
    "like" : {
      "tweetId" : "429138420586143746",
      "fullText" : "@PrtScnSysRq aural assault",
      "expandedUrl" : "https://twitter.com/i/web/status/429138420586143746"
    }
  },
  {
    "like" : {
      "tweetId" : "430517165549043712",
      "fullText" : "@officedepot you are beautiful",
      "expandedUrl" : "https://twitter.com/i/web/status/430517165549043712"
    }
  },
  {
    "like" : {
      "tweetId" : "430537539632390147",
      "fullText" : "People at the grocery store get startled just because I look and walk like I'm actually there for a reason.",
      "expandedUrl" : "https://twitter.com/i/web/status/430537539632390147"
    }
  },
  {
    "like" : {
      "tweetId" : "429792922322882561",
      "fullText" : "I'm about to take double my dose of Adderall again.",
      "expandedUrl" : "https://twitter.com/i/web/status/429792922322882561"
    }
  },
  {
    "like" : {
      "tweetId" : "429144209602273280",
      "fullText" : "I NEED TO EAT before i record new drywall EP",
      "expandedUrl" : "https://twitter.com/i/web/status/429144209602273280"
    }
  },
  {
    "like" : {
      "tweetId" : "430756037503627265",
      "fullText" : "livestream my alcohol sale test",
      "expandedUrl" : "https://twitter.com/i/web/status/430756037503627265"
    }
  },
  {
    "like" : {
      "tweetId" : "431223261238525952",
      "fullText" : "I'm going to create a human trafficking operation and buy a new 2014 Rolls-Royce Wraith.",
      "expandedUrl" : "https://twitter.com/i/web/status/431223261238525952"
    }
  },
  {
    "like" : {
      "tweetId" : "431358246272503809",
      "fullText" : "REMINDER: https://t.co/uwLBrypQg0",
      "expandedUrl" : "https://twitter.com/i/web/status/431358246272503809"
    }
  },
  {
    "like" : {
      "tweetId" : "431312555445731328",
      "fullText" : "I made the wrong sounds near you, you heard them, now you're upset.",
      "expandedUrl" : "https://twitter.com/i/web/status/431312555445731328"
    }
  },
  {
    "like" : {
      "tweetId" : "431333894953000960",
      "fullText" : "@lifelohie http://t.co/eiuoU6PVpT",
      "expandedUrl" : "https://twitter.com/i/web/status/431333894953000960"
    }
  },
  {
    "like" : {
      "tweetId" : "431334562195447808",
      "fullText" : "who visited the fucking drywall website in netscape",
      "expandedUrl" : "https://twitter.com/i/web/status/431334562195447808"
    }
  },
  {
    "like" : {
      "tweetId" : "431358911417819137",
      "fullText" : "@PrtScnSysRq OH MYUY GOD",
      "expandedUrl" : "https://twitter.com/i/web/status/431358911417819137"
    }
  },
  {
    "like" : {
      "tweetId" : "431214563443224576",
      "fullText" : "Human trafficking is gonna be the next drywall thing.",
      "expandedUrl" : "https://twitter.com/i/web/status/431214563443224576"
    }
  },
  {
    "like" : {
      "tweetId" : "431333624974028801",
      "fullText" : "what if I just made an iphone video of me singing the chorus to this track because that's what I want to do right now http://t.co/YmqqgEQzaZ",
      "expandedUrl" : "https://twitter.com/i/web/status/431333624974028801"
    }
  },
  {
    "like" : {
      "tweetId" : "431359909523775488",
      "fullText" : "Robert Earl Davis III",
      "expandedUrl" : "https://twitter.com/i/web/status/431359909523775488"
    }
  },
  {
    "like" : {
      "tweetId" : "431312477679132672",
      "fullText" : "I could make sounds with my mouth and if they resembled certain things I could be shot.",
      "expandedUrl" : "https://twitter.com/i/web/status/431312477679132672"
    }
  },
  {
    "like" : {
      "tweetId" : "430775358153973760",
      "fullText" : "\"I wish I could maul you.\" http://t.co/WjOzUlD8ph",
      "expandedUrl" : "https://twitter.com/i/web/status/430775358153973760"
    }
  },
  {
    "like" : {
      "tweetId" : "431223932461412352",
      "fullText" : "If only the government didn't exist then I could sell Indian children and drive a rolls-royce.",
      "expandedUrl" : "https://twitter.com/i/web/status/431223932461412352"
    }
  },
  {
    "like" : {
      "tweetId" : "431311045312151552",
      "fullText" : "@ruskimalooski \"I'm going to rape you.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/431311045312151552"
    }
  },
  {
    "like" : {
      "tweetId" : "431213682123485185",
      "fullText" : "Apparently I could buy a Pakistani woman for $342",
      "expandedUrl" : "https://twitter.com/i/web/status/431213682123485185"
    }
  },
  {
    "like" : {
      "tweetId" : "431334064197365761",
      "fullText" : "THIS TRACK IS PERFECT http://t.co/YmqqgEQzaZ",
      "expandedUrl" : "https://twitter.com/i/web/status/431334064197365761"
    }
  },
  {
    "like" : {
      "tweetId" : "431310998503292928",
      "fullText" : "@ruskimalooski \"I'm going to kill you\"",
      "expandedUrl" : "https://twitter.com/i/web/status/431310998503292928"
    }
  },
  {
    "like" : {
      "tweetId" : "431222705736519680",
      "fullText" : "I was thinking about human trafficking as an extremely lucrative business opportunity while I was shoveling my mom's driveway.",
      "expandedUrl" : "https://twitter.com/i/web/status/431222705736519680"
    }
  },
  {
    "like" : {
      "tweetId" : "431215004826619904",
      "fullText" : "FINALLY  http://t.co/a4vzuxXamM",
      "expandedUrl" : "https://twitter.com/i/web/status/431215004826619904"
    }
  },
  {
    "like" : {
      "tweetId" : "431222549670686720",
      "fullText" : "hello I shoveled snow and I can't move",
      "expandedUrl" : "https://twitter.com/i/web/status/431222549670686720"
    }
  },
  {
    "like" : {
      "tweetId" : "431359836547084288",
      "fullText" : "DJ screw you are my dad",
      "expandedUrl" : "https://twitter.com/i/web/status/431359836547084288"
    }
  },
  {
    "like" : {
      "tweetId" : "431312371819499520",
      "fullText" : "imagine a world where people are caged at gunpoint for the sounds they produce with their mouths.  it's right now.",
      "expandedUrl" : "https://twitter.com/i/web/status/431312371819499520"
    }
  },
  {
    "like" : {
      "tweetId" : "431312903929888769",
      "fullText" : "Imagine an ENTIRE SOCIAL MOVEMENT taking action against people for the sounds they make",
      "expandedUrl" : "https://twitter.com/i/web/status/431312903929888769"
    }
  },
  {
    "like" : {
      "tweetId" : "431332178752839680",
      "fullText" : "have you played the video game",
      "expandedUrl" : "https://twitter.com/i/web/status/431332178752839680"
    }
  },
  {
    "like" : {
      "tweetId" : "431217086346457088",
      "fullText" : "Drywall's new pursuit: importing children from India. Instant 20,000% profit",
      "expandedUrl" : "https://twitter.com/i/web/status/431217086346457088"
    }
  },
  {
    "like" : {
      "tweetId" : "431314551448285184",
      "fullText" : "@ptg34 hi",
      "expandedUrl" : "https://twitter.com/i/web/status/431314551448285184"
    }
  },
  {
    "like" : {
      "tweetId" : "431937740586766337",
      "fullText" : "BE IN A JAZZ BAND WITH ME",
      "expandedUrl" : "https://twitter.com/i/web/status/431937740586766337"
    }
  },
  {
    "like" : {
      "tweetId" : "431942541559488513",
      "fullText" : "@Collin__P fuck",
      "expandedUrl" : "https://twitter.com/i/web/status/431942541559488513"
    }
  },
  {
    "like" : {
      "tweetId" : "431936433020882945",
      "fullText" : "funk3 http://t.co/f4R23hoLGt",
      "expandedUrl" : "https://twitter.com/i/web/status/431936433020882945"
    }
  },
  {
    "like" : {
      "tweetId" : "431389762059243520",
      "fullText" : "I'm listening to a podcast I recorded 5 years ago help",
      "expandedUrl" : "https://twitter.com/i/web/status/431389762059243520"
    }
  },
  {
    "like" : {
      "tweetId" : "431944895549673472",
      "fullText" : "human horn",
      "expandedUrl" : "https://twitter.com/i/web/status/431944895549673472"
    }
  },
  {
    "like" : {
      "tweetId" : "431385140422377472",
      "fullText" : "I'm probably going to get fired from my family",
      "expandedUrl" : "https://twitter.com/i/web/status/431385140422377472"
    }
  },
  {
    "like" : {
      "tweetId" : "431942263971659776",
      "fullText" : "RARE DRYWALL FILM WITH COMMENTARY http://t.co/TWQaewFol3",
      "expandedUrl" : "https://twitter.com/i/web/status/431942263971659776"
    }
  },
  {
    "like" : {
      "tweetId" : "431395359877640192",
      "fullText" : "\"are you crazy\" - my mom",
      "expandedUrl" : "https://twitter.com/i/web/status/431395359877640192"
    }
  },
  {
    "like" : {
      "tweetId" : "431394032036478976",
      "fullText" : "me in 2010 http://t.co/NqVhdUJ7oF",
      "expandedUrl" : "https://twitter.com/i/web/status/431394032036478976"
    }
  },
  {
    "like" : {
      "tweetId" : "431944352294645760",
      "fullText" : "clipping is still the funniest thing",
      "expandedUrl" : "https://twitter.com/i/web/status/431944352294645760"
    }
  },
  {
    "like" : {
      "tweetId" : "431386254929047552",
      "fullText" : "@doctorkohaku I think collinp is playing but otherwise no",
      "expandedUrl" : "https://twitter.com/i/web/status/431386254929047552"
    }
  },
  {
    "like" : {
      "tweetId" : "431937177690189824",
      "fullText" : "@FUCKPUPPYONLINE K I L L E R",
      "expandedUrl" : "https://twitter.com/i/web/status/431937177690189824"
    }
  },
  {
    "like" : {
      "tweetId" : "431393862628548608",
      "fullText" : "the original apathetic cake gluttons folder is over 10GB http://t.co/K07TIeVzEX",
      "expandedUrl" : "https://twitter.com/i/web/status/431393862628548608"
    }
  },
  {
    "like" : {
      "tweetId" : "431943509583474688",
      "fullText" : "@Collin__P collinp dont die",
      "expandedUrl" : "https://twitter.com/i/web/status/431943509583474688"
    }
  },
  {
    "like" : {
      "tweetId" : "431942840965292032",
      "fullText" : "MEMES",
      "expandedUrl" : "https://twitter.com/i/web/status/431942840965292032"
    }
  },
  {
    "like" : {
      "tweetId" : "431446124713353216",
      "fullText" : "@ruskimalooski rusk look what I did http://t.co/CO9rZTrgej",
      "expandedUrl" : "https://twitter.com/i/web/status/431446124713353216"
    }
  },
  {
    "like" : {
      "tweetId" : "431444398971183104",
      "fullText" : "THE DRYWALL WEBSITE'S UPCOMING NEW LOOK http://t.co/0b9SEfDJdg",
      "expandedUrl" : "https://twitter.com/i/web/status/431444398971183104"
    }
  },
  {
    "like" : {
      "tweetId" : "430599051126382593",
      "fullText" : "The frightened girl gamer http://t.co/t3nQqhW7Pr",
      "expandedUrl" : "https://twitter.com/i/web/status/430599051126382593"
    }
  },
  {
    "like" : {
      "tweetId" : "431384198604398592",
      "fullText" : "@AppStore how can I make osx look like windows 7",
      "expandedUrl" : "https://twitter.com/i/web/status/431384198604398592"
    }
  },
  {
    "like" : {
      "tweetId" : "431402162061463552",
      "fullText" : "OH MY GOD I'VE ACTUALLY DONE IT http://t.co/CO9rZTrgej http://t.co/Ajl2gCsHwT",
      "expandedUrl" : "https://twitter.com/i/web/status/431402162061463552"
    }
  },
  {
    "like" : {
      "tweetId" : "431394923930071040",
      "fullText" : "a video of me driving a golf gti in 2011 that my mom took",
      "expandedUrl" : "https://twitter.com/i/web/status/431394923930071040"
    }
  },
  {
    "like" : {
      "tweetId" : "431382823434346496",
      "fullText" : "http://t.co/LKwybzzFYM",
      "expandedUrl" : "https://twitter.com/i/web/status/431382823434346496"
    }
  },
  {
    "like" : {
      "tweetId" : "431384315482886144",
      "fullText" : "I used Evernote before it was cool.",
      "expandedUrl" : "https://twitter.com/i/web/status/431384315482886144"
    }
  },
  {
    "like" : {
      "tweetId" : "431945831382392832",
      "fullText" : "@Kindle fuck me",
      "expandedUrl" : "https://twitter.com/i/web/status/431945831382392832"
    }
  },
  {
    "like" : {
      "tweetId" : "431945276446613504",
      "fullText" : "http://t.co/5HOxzZpmLg",
      "expandedUrl" : "https://twitter.com/i/web/status/431945276446613504"
    }
  },
  {
    "like" : {
      "tweetId" : "432162236753125378",
      "fullText" : "apparently the formula for success on youtube is to stream a game you don't know how to play",
      "expandedUrl" : "https://twitter.com/i/web/status/432162236753125378"
    }
  },
  {
    "like" : {
      "tweetId" : "432168870363676672",
      "fullText" : "\"drywall over obama care.\" - @rkellyfucks http://t.co/0X9uLKtTfI",
      "expandedUrl" : "https://twitter.com/i/web/status/432168870363676672"
    }
  },
  {
    "like" : {
      "tweetId" : "432159234050887680",
      "fullText" : "or maybe not",
      "expandedUrl" : "https://twitter.com/i/web/status/432159234050887680"
    }
  },
  {
    "like" : {
      "tweetId" : "432160624148090881",
      "fullText" : "good morning 93",
      "expandedUrl" : "https://twitter.com/i/web/status/432160624148090881"
    }
  },
  {
    "like" : {
      "tweetId" : "432159485981753346",
      "fullText" : "help http://t.co/MWo7kjOiCy",
      "expandedUrl" : "https://twitter.com/i/web/status/432159485981753346"
    }
  },
  {
    "like" : {
      "tweetId" : "432175846833414147",
      "fullText" : "I CAN'T PASS THIS FUCKING STATE ALCOHOL SALE TEST AAAAA",
      "expandedUrl" : "https://twitter.com/i/web/status/432175846833414147"
    }
  },
  {
    "like" : {
      "tweetId" : "431946753189756928",
      "fullText" : "@ruskimalooski srmdtg hmj,",
      "expandedUrl" : "https://twitter.com/i/web/status/431946753189756928"
    }
  },
  {
    "like" : {
      "tweetId" : "431946655080800256",
      "fullText" : "Hello http://t.co/9gDAZkUS76",
      "expandedUrl" : "https://twitter.com/i/web/status/431946655080800256"
    }
  },
  {
    "like" : {
      "tweetId" : "432162527502282753",
      "fullText" : "@collin__p http://t.co/uwdM7tGulw",
      "expandedUrl" : "https://twitter.com/i/web/status/432162527502282753"
    }
  },
  {
    "like" : {
      "tweetId" : "432159719038279680",
      "fullText" : "my british friend/editor of the car blog I used to write for is making inter-region jokes on Facebook and I don't understand them",
      "expandedUrl" : "https://twitter.com/i/web/status/432159719038279680"
    }
  },
  {
    "like" : {
      "tweetId" : "432166038369603585",
      "fullText" : "@collin__p idk I guess I just thought they'd help if any gallante came in because that's kinda the point of being in the same faction",
      "expandedUrl" : "https://twitter.com/i/web/status/432166038369603585"
    }
  },
  {
    "like" : {
      "tweetId" : "432161766395486210",
      "fullText" : "so basically \"tweeting [my] data\" is just tweeting an ad lol",
      "expandedUrl" : "https://twitter.com/i/web/status/432161766395486210"
    }
  },
  {
    "like" : {
      "tweetId" : "432167944676573184",
      "fullText" : "@collin__p yeah in like 2008 I decided I would build one of these myself (very dumb) and I spent the money to do it. https://t.co/BQknT5FufU",
      "expandedUrl" : "https://twitter.com/i/web/status/432167944676573184"
    }
  },
  {
    "like" : {
      "tweetId" : "432166959463944192",
      "fullText" : "@collin__p yeah they had 2 cruisers but there were like 8 frigates in that plex (including me.)  I guess I should've just bailed too.",
      "expandedUrl" : "https://twitter.com/i/web/status/432166959463944192"
    }
  },
  {
    "like" : {
      "tweetId" : "432161788067463168",
      "fullText" : "I like the way these people work",
      "expandedUrl" : "https://twitter.com/i/web/status/432161788067463168"
    }
  },
  {
    "like" : {
      "tweetId" : "432162990687662080",
      "fullText" : "I have to take my alcohol sales test will  you help me cheat twitter",
      "expandedUrl" : "https://twitter.com/i/web/status/432162990687662080"
    }
  },
  {
    "like" : {
      "tweetId" : "432158301560647681",
      "fullText" : "@Collin__P RIP Saab",
      "expandedUrl" : "https://twitter.com/i/web/status/432158301560647681"
    }
  },
  {
    "like" : {
      "tweetId" : "432161572614455296",
      "fullText" : "I just cleared 8 GB using Disk Doctor for Mac. Check it out here: http://t.co/YpMnjWF0RZ #diskdoctor #fiplab",
      "expandedUrl" : "https://twitter.com/i/web/status/432161572614455296"
    }
  },
  {
    "like" : {
      "tweetId" : "432165416400846848",
      "fullText" : "@collin__p the best part is around 15:30 when the two guys warp in and I lose my ship and NOBODY helps me",
      "expandedUrl" : "https://twitter.com/i/web/status/432165416400846848"
    }
  },
  {
    "like" : {
      "tweetId" : "432158572445569024",
      "fullText" : "hello I am bad at life",
      "expandedUrl" : "https://twitter.com/i/web/status/432158572445569024"
    }
  },
  {
    "like" : {
      "tweetId" : "432161355726999552",
      "fullText" : "why the fuck would I want to tweet the data of my disk cleaning utility",
      "expandedUrl" : "https://twitter.com/i/web/status/432161355726999552"
    }
  },
  {
    "like" : {
      "tweetId" : "432166721399435265",
      "fullText" : "@collin__p using other people to get ahead is one of my favorite things in life",
      "expandedUrl" : "https://twitter.com/i/web/status/432166721399435265"
    }
  },
  {
    "like" : {
      "tweetId" : "432166136436625408",
      "fullText" : "@collin__p also we could've easily taken them down but they decided to warp out instead",
      "expandedUrl" : "https://twitter.com/i/web/status/432166136436625408"
    }
  },
  {
    "like" : {
      "tweetId" : "432162112819822592",
      "fullText" : "holy shit that eve online video I did is gaining views quickly",
      "expandedUrl" : "https://twitter.com/i/web/status/432162112819822592"
    }
  },
  {
    "like" : {
      "tweetId" : "432159212227928064",
      "fullText" : "someday maybe I'll understand all the british inter-region jokes",
      "expandedUrl" : "https://twitter.com/i/web/status/432159212227928064"
    }
  },
  {
    "like" : {
      "tweetId" : "431836065159057408",
      "fullText" : "@Mickeyriku youre gonna give me an heart attacl",
      "expandedUrl" : "https://twitter.com/i/web/status/431836065159057408"
    }
  },
  {
    "like" : {
      "tweetId" : "431707153192075265",
      "fullText" : "Chem labs start next week too. Sweatin",
      "expandedUrl" : "https://twitter.com/i/web/status/431707153192075265"
    }
  },
  {
    "like" : {
      "tweetId" : "431824485977567232",
      "fullText" : "monkey mane",
      "expandedUrl" : "https://twitter.com/i/web/status/431824485977567232"
    }
  },
  {
    "like" : {
      "tweetId" : "431609196052611073",
      "fullText" : "very complex and saddening dark souls lore",
      "expandedUrl" : "https://twitter.com/i/web/status/431609196052611073"
    }
  },
  {
    "like" : {
      "tweetId" : "431703451437768704",
      "fullText" : "http://t.co/Rj6Hjrq4Wc",
      "expandedUrl" : "https://twitter.com/i/web/status/431703451437768704"
    }
  },
  {
    "like" : {
      "tweetId" : "431704309785698304",
      "fullText" : "I dont get to rest much i miss last semester when i got to sleep in till noon",
      "expandedUrl" : "https://twitter.com/i/web/status/431704309785698304"
    }
  },
  {
    "like" : {
      "tweetId" : "432175960654229505",
      "fullText" : "I've been trying for a total of like 3 hours now and all the other employees took less than an hour $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",
      "expandedUrl" : "https://twitter.com/i/web/status/432175960654229505"
    }
  },
  {
    "like" : {
      "tweetId" : "431816852839202816",
      "fullText" : "@efflugent @Harihara_ BREAKFAST IS THE MOST IMPORTANT MEAL OF THE DAY!",
      "expandedUrl" : "https://twitter.com/i/web/status/431816852839202816"
    }
  },
  {
    "like" : {
      "tweetId" : "431609368048459776",
      "fullText" : "@thebigtitty this picture is amazing",
      "expandedUrl" : "https://twitter.com/i/web/status/431609368048459776"
    }
  },
  {
    "like" : {
      "tweetId" : "431705843923296256",
      "fullText" : "@crimegolem i'll try to keep my stupud mouth shut",
      "expandedUrl" : "https://twitter.com/i/web/status/431705843923296256"
    }
  },
  {
    "like" : {
      "tweetId" : "431592958840684544",
      "fullText" : "@fanfiction_txt https://t.co/e6S5DFey6M",
      "expandedUrl" : "https://twitter.com/i/web/status/431592958840684544"
    }
  },
  {
    "like" : {
      "tweetId" : "431704508549189632",
      "fullText" : "Not a big fan of online work or classes",
      "expandedUrl" : "https://twitter.com/i/web/status/431704508549189632"
    }
  },
  {
    "like" : {
      "tweetId" : "431706680984756224",
      "fullText" : "Hopefully i can sell one of my books tomorrow",
      "expandedUrl" : "https://twitter.com/i/web/status/431706680984756224"
    }
  },
  {
    "like" : {
      "tweetId" : "431706285768458240",
      "fullText" : "is this real. are we even living in the alpha timeline rn http://t.co/ptBpkEDHO2",
      "expandedUrl" : "https://twitter.com/i/web/status/431706285768458240"
    }
  },
  {
    "like" : {
      "tweetId" : "431609257146871808",
      "fullText" : "i want to forge and cosplay elite knight-kun",
      "expandedUrl" : "https://twitter.com/i/web/status/431609257146871808"
    }
  },
  {
    "like" : {
      "tweetId" : "431704458850885632",
      "fullText" : "Half of my guitar class is held entirely online i dunno what to think about that",
      "expandedUrl" : "https://twitter.com/i/web/status/431704458850885632"
    }
  },
  {
    "like" : {
      "tweetId" : "432176029843472387",
      "fullText" : "WHY AM I SO BAD AT THINGS",
      "expandedUrl" : "https://twitter.com/i/web/status/432176029843472387"
    }
  },
  {
    "like" : {
      "tweetId" : "431609183155134465",
      "fullText" : "when i am talking to someone very cool.. http://t.co/bEiiOEVeZ1",
      "expandedUrl" : "https://twitter.com/i/web/status/431609183155134465"
    }
  },
  {
    "like" : {
      "tweetId" : "431836502973095936",
      "fullText" : "@Mickeyriku whats dead may never die",
      "expandedUrl" : "https://twitter.com/i/web/status/431836502973095936"
    }
  },
  {
    "like" : {
      "tweetId" : "431705478142251008",
      "fullText" : "@crimegolem i dont really like being a jerk",
      "expandedUrl" : "https://twitter.com/i/web/status/431705478142251008"
    }
  },
  {
    "like" : {
      "tweetId" : "431816243461378049",
      "fullText" : "*takes you to the dollar tree* pick out everything your heart desires bae.",
      "expandedUrl" : "https://twitter.com/i/web/status/431816243461378049"
    }
  },
  {
    "like" : {
      "tweetId" : "431703963230941184",
      "fullText" : "LASER GUIDED PIZZA CUTTER",
      "expandedUrl" : "https://twitter.com/i/web/status/431703963230941184"
    }
  },
  {
    "like" : {
      "tweetId" : "431705580634251265",
      "fullText" : "@solvemypuzzles its embarassing",
      "expandedUrl" : "https://twitter.com/i/web/status/431705580634251265"
    }
  },
  {
    "like" : {
      "tweetId" : "431707711969824768",
      "fullText" : "Goodnight",
      "expandedUrl" : "https://twitter.com/i/web/status/431707711969824768"
    }
  },
  {
    "like" : {
      "tweetId" : "431346541786173440",
      "fullText" : "本日よりフライドフィッシュが復活！！こちらの、フライドポテトLとフライドフィッシュがセットになったフィッシュ＆チップス(380円)はちょっとお腹がすいたときにピッタリ♪ #フィッシュ復活 http://t.co/5HBoNxmMhG",
      "expandedUrl" : "https://twitter.com/i/web/status/431346541786173440"
    }
  }
]