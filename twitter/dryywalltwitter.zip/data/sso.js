window.YTD.sso.part0 = [
  {
    "singleSignOnMetaValues" : {
      "ssoId" : "110372435165296960781",
      "ssoEmail" : "ihadtopee@gmail.com",
      "associationMethodType" : "Login",
      "createdAt" : "2021-11-19T06:06:49.110Z"
    }
  }
]