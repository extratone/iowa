window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "396069845"
    }
  }
]