window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "396069845",
      "emailChange" : {
        "changedAt" : "2011-10-22T18:12:28.000Z",
        "changedTo" : "ihadtopee@gmail.com"
      }
    }
  }
]